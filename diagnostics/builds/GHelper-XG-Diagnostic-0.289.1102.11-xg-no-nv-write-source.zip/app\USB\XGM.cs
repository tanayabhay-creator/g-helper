﻿// Reference : thanks to https://github.com/RomanYazvinsky/ for initial discovery of XGM payloads

using GHelper.Helpers;
using HidSharp;
using System.Text;

namespace GHelper.USB
{
    public static class XGM
    {
        const byte XGM_REPORT_ID = 0x5e;
        const int ASUS_ID = 0x0b05;
        static readonly int[] deviceIds = { 0x1970, 0x1a9a, 0x1C28, 0x1C29, 0x1BC1 };

        public static HidDevice? GetDevice()
        {
            try
            {
                /*
                var devices = DeviceList.Local.GetHidDevices(ASUS_ID).Where(device =>
                    deviceIds.Contains(device.ProductID) &&
                    device.CanOpen &&
                    device.GetMaxFeatureReportLength() >= 300);

                foreach (var device in devices)
                {
                    var report = device.GetReportDescriptor().TryGetReport(ReportType.Feature, XGM_REPORT_ID, out _);
                    Logger.WriteLine($"Found XGM Device: PID={device.ProductID}, MaxFeatureReportLength={device.GetMaxFeatureReportLength()}, Report={report}");
                }
                */
                return DeviceList.Local.GetHidDevices(ASUS_ID).FirstOrDefault(device =>
                    deviceIds.Contains(device.ProductID) &&
                    device.CanOpen &&
                    device.GetMaxFeatureReportLength() >= 300);
            }
            catch (Exception ex)
            {
                Logger.WriteLine($"Error getting XGM device: {ex}");
                return null;
            }
        }

        public static bool IsConnected()
        {
            return GetDevice() is not null;
        }

        public static void Write(byte[] data)
        {
            try
            {
                HidDevice? device = GetDevice();
                if (device is null)
                {
                    Logger.WriteLine("XGM SUB device not found");
                    return;
                }

                using (HidStream hidStream = device.Open())
                {
                    byte[] payload = new byte[300];
                    data.CopyTo(payload, 0);
                    hidStream.SetFeature(payload);
                    Logger.WriteLine($"XGM-{device.ProductID}|{device.GetMaxFeatureReportLength()}:{BitConverter.ToString(data)}");
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLine($"Error accessing XGM device: {ex}");
            }

        }

        public static void Init()
        {
            Task.Run(() =>
            {
                if (IsConnected())
                {
                    Write(Encoding.ASCII.GetBytes("^ASUS Tech.Inc."));
                    Write([XGM_REPORT_ID, 0xE4, 0x02]);
                    Light(AppConfig.Is("xmg_light"));
                }
            });
        }

        public static void Light(bool status)
        {
            Write([XGM_REPORT_ID, 0xc5, status ? (byte)0x50 : (byte)0]);
            Write([XGM_REPORT_ID, 0xbd, 0x00, status ? (byte)0x01 : (byte)0x00]);
        }

        public static void LightBrightness(int brightness)
        {
            Task.Run(() =>
            {
                if (IsConnected())
                {
                    Write([XGM_REPORT_ID, 0xba, 0xc5, 0xc4, (byte)brightness]);
                }
            });
        }

        public static void LightMode(AuraMode mode, Color color, Color color2, int speed)
        {
            Task.Run(() =>
            {
                if (IsConnected())
                {
                    var msg = Aura.AuraMessage(mode, color, color2, speed);
                    msg[0] = XGM_REPORT_ID;
                    Write(msg);
                    Write([XGM_REPORT_ID, 0xb4]);
                    Write([XGM_REPORT_ID, 0xb5]);
                }
            });
        }

        public static void InitLight()
        {
            Task.Run(() =>
            {
                if (IsConnected()) Light(AppConfig.Is("xmg_light"));
            });
        }

        public static void NotifyShutdown()
        {
            if (IsConnected()) Write([XGM_REPORT_ID, 0xE4, 0x01]);
        }

        public static void Reset()
        {
            Task.Run(() =>
            {
                if (IsConnected()) Write([XGM_REPORT_ID, 0xd1, 0x02]);
            });
        }

        public static void SetFan(byte[] curve)
        {
            Task.Run(() =>
            {
                if (AsusACPI.IsInvalidCurve(curve)) return;
                if (IsConnected()) Write([XGM_REPORT_ID, 0xd1, 0x01, .. curve]);
            });
        }
    }
}
