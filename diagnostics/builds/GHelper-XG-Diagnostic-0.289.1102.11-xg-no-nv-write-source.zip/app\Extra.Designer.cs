﻿using GHelper.Properties;
using GHelper.UI;

namespace GHelper
{
    partial class Extra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panelServices = new Panel();
            pictureService = new PictureBox();
            labelServices = new Label();
            buttonServices = new RButton();
            panelBindingsHeader = new Panel();
            buttonResetBindings = new RButton();
            pictureBindings = new PictureBox();
            pictureHelp = new PictureBox();
            labelBindings = new Label();
            panelBindings = new Panel();
            tableBindings = new TableLayoutPanel();
            labelFNE = new Label();
            comboFNE = new RComboBox();
            textFNE = new RTextBox();
            labelFNV = new Label();
            comboFNV = new RComboBox();
            textFNV = new RTextBox();
            labelFNC = new Label();
            comboFNC = new RComboBox();
            textFNC = new RTextBox();
            labelFNF4 = new Label();
            comboFNF4 = new RComboBox();
            textFNF4 = new RTextBox();
            comboM4 = new RComboBox();
            textM4 = new RTextBox();
            labelM4 = new Label();
            comboM5 = new RComboBox();
            textM5 = new RTextBox();
            labelM5 = new Label();
            comboM3 = new RComboBox();
            textM3 = new RTextBox();
            labelM3 = new Label();
            textM2 = new RTextBox();
            labelM2 = new Label();
            comboM2 = new RComboBox();
            textM1 = new RTextBox();
            comboM1 = new RComboBox();
            labelM1 = new Label();
            tableKeys = new TableLayoutPanel();
            panelBacklightHeader = new Panel();
            sliderBrightness = new Slider();
            pictureBacklight = new PictureBox();
            labelBacklightTitle = new Label();
            panelBacklight = new Panel();
            panelBacklightExtra = new Panel();
            numericBacklightPluggedTime = new NumericUpDownWithUnit();
            numericBacklightTime = new NumericUpDownWithUnit();
            labelBacklightTimeout = new Label();
            labelSpeed = new Label();
            comboKeyboardSpeed = new RComboBox();
            panelXGM = new Panel();
            checkXGM = new CheckBox();
            tableBacklight = new TableLayoutPanel();
            labelBacklightKeyboard = new Label();
            checkAwake = new CheckBox();
            checkBoot = new CheckBox();
            checkSleep = new CheckBox();
            checkBattery = new CheckBox();
            labelBacklightLogo = new Label();
            checkAwakeLogo = new CheckBox();
            checkBootLogo = new CheckBox();
            checkSleepLogo = new CheckBox();
            checkBatteryLogo = new CheckBox();
            labelBacklightBar = new Label();
            checkAwakeBar = new CheckBox();
            checkBootBar = new CheckBox();
            checkSleepBar = new CheckBox();
            checkBatteryBar = new CheckBox();
            labelBacklightLid = new Label();
            checkAwakeLid = new CheckBox();
            checkBootLid = new CheckBox();
            checkSleepLid = new CheckBox();
            checkBatteryLid = new CheckBox();
            panelSettingsHeader = new Panel();
            pictureScan = new PictureBox();
            pictureLog = new PictureBox();
            pictureSettings = new PictureBox();
            labelSettings = new Label();
            panelSettings = new Panel();
            checkAutoToggleClamshellMode = new CheckBox();
            checkTopmost = new CheckBox();
            checkNoOverdrive = new CheckBox();
            checkELMB = new CheckBox();
            checkBootSound = new CheckBox();
            checkKeystoneSound = new CheckBox();
            checkUSBC = new CheckBox();
            checkGpuApps = new CheckBox();
            checkNVPlatform = new CheckBox();
            checkStatusLed = new CheckBox();
            checkNumberPad = new CheckBox();
            checkAspm = new CheckBox();
            checkStandbyNetworking = new CheckBox();
            panelPower = new Panel();
            numericHibernateAfter = new NumericUpDownWithUnit();
            labelHibernateAfter = new Label();
            pictureHibernate = new PictureBox();
            toolTip = new ToolTip(components);
            panelAPU = new Panel();
            comboAPU = new RComboBox();
            pictureAPUMem = new PictureBox();
            labelAPUMem = new Label();
            panelCores = new Panel();
            buttonCores = new RButton();
            comboCoresP = new RComboBox();
            comboCoresE = new RComboBox();
            pictureCores = new PictureBox();
            labelCores = new Label();
            panelACPI = new Panel();
            textACPIParam = new RTextBox();
            textACPICommand = new RTextBox();
            buttonACPISend = new RButton();
            pictureDebug = new PictureBox();
            labelACPITitle = new Label();
            panelOptimalBrightness = new Panel();
            comboOptimalBrightness = new RComboBox();
            pictureOptimalBrightness = new PictureBox();
            labelOptimalBrightness = new Label();
            panelServices.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureService).BeginInit();
            panelBindingsHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBindings).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureHelp).BeginInit();
            panelBindings.SuspendLayout();
            tableBindings.SuspendLayout();
            panelBacklightHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBacklight).BeginInit();
            panelBacklight.SuspendLayout();
            panelBacklightExtra.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericBacklightPluggedTime).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericBacklightTime).BeginInit();
            panelXGM.SuspendLayout();
            tableBacklight.SuspendLayout();
            panelSettingsHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureScan).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureLog).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureSettings).BeginInit();
            panelSettings.SuspendLayout();
            panelPower.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericHibernateAfter).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureHibernate).BeginInit();
            panelAPU.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureAPUMem).BeginInit();
            panelCores.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureCores).BeginInit();
            panelACPI.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureDebug).BeginInit();
            panelOptimalBrightness.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureOptimalBrightness).BeginInit();
            SuspendLayout();
            // 
            // panelServices
            // 
            panelServices.AccessibleRole = AccessibleRole.Grouping;
            panelServices.Controls.Add(pictureService);
            panelServices.Controls.Add(labelServices);
            panelServices.Controls.Add(buttonServices);
            panelServices.Dock = DockStyle.Top;
            panelServices.Location = new Point(15, 1778);
            panelServices.Name = "panelServices";
            panelServices.Size = new Size(949, 75);
            panelServices.TabIndex = 5;
            // 
            // pictureService
            // 
            pictureService.BackgroundImage = Resources.icons8_automation_32;
            pictureService.BackgroundImageLayout = ImageLayout.Zoom;
            pictureService.Location = new Point(21, 19);
            pictureService.Name = "pictureService";
            pictureService.Size = new Size(32, 32);
            pictureService.TabIndex = 21;
            pictureService.TabStop = false;
            // 
            // labelServices
            // 
            labelServices.AutoSize = true;
            labelServices.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            labelServices.Location = new Point(57, 19);
            labelServices.Name = "labelServices";
            labelServices.Size = new Size(273, 32);
            labelServices.TabIndex = 20;
            labelServices.Text = "Asus Services Running";
            // 
            // buttonServices
            // 
            buttonServices.Activated = false;
            buttonServices.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            buttonServices.BackColor = SystemColors.ButtonHighlight;
            buttonServices.BorderColor = Color.Transparent;
            buttonServices.BorderRadius = 2;
            buttonServices.FlatStyle = FlatStyle.Flat;
            buttonServices.Location = new Point(713, 11);
            buttonServices.Margin = new Padding(5, 3, 5, 3);
            buttonServices.Name = "buttonServices";
            buttonServices.Secondary = false;
            buttonServices.Size = new Size(256, 53);
            buttonServices.TabIndex = 19;
            buttonServices.Text = "Start Services";
            buttonServices.UseVisualStyleBackColor = false;
            // 
            // panelBindingsHeader
            // 
            panelBindingsHeader.AutoSize = true;
            panelBindingsHeader.BackColor = SystemColors.ControlLight;
            panelBindingsHeader.Controls.Add(buttonResetBindings);
            panelBindingsHeader.Controls.Add(pictureBindings);
            panelBindingsHeader.Controls.Add(pictureHelp);
            panelBindingsHeader.Controls.Add(labelBindings);
            panelBindingsHeader.Dock = DockStyle.Top;
            panelBindingsHeader.Location = new Point(15, 15);
            panelBindingsHeader.Name = "panelBindingsHeader";
            panelBindingsHeader.Padding = new Padding(11, 5, 11, 5);
            panelBindingsHeader.Size = new Size(949, 51);
            panelBindingsHeader.TabIndex = 4;
            // 
            // pictureBindings
            // 
            pictureBindings.BackgroundImage = Resources.icons8_keyboard_32;
            pictureBindings.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBindings.Location = new Point(21, 11);
            pictureBindings.Name = "pictureBindings";
            pictureBindings.Size = new Size(32, 32);
            pictureBindings.TabIndex = 1;
            pictureBindings.TabStop = false;
            //
            // buttonResetBindings
            //
            buttonResetBindings.Activated = false;
            buttonResetBindings.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            buttonResetBindings.BackColor = SystemColors.ButtonHighlight;
            buttonResetBindings.BorderColor = Color.Transparent;
            buttonResetBindings.BorderRadius = 2;
            buttonResetBindings.FlatStyle = FlatStyle.Flat;
            buttonResetBindings.Location = new Point(727, 5);
            buttonResetBindings.Margin = new Padding(5, 3, 5, 3);
            buttonResetBindings.Name = "buttonResetBindings";
            buttonResetBindings.Secondary = true;
            buttonResetBindings.Size = new Size(150, 41);
            buttonResetBindings.TabIndex = 12;
            buttonResetBindings.Text = "Reset";
            buttonResetBindings.UseVisualStyleBackColor = false;
            //
            // pictureHelp
            //
            pictureHelp.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pictureHelp.BackgroundImage = Resources.icons8_help_32;
            pictureHelp.BackgroundImageLayout = ImageLayout.Zoom;
            pictureHelp.Cursor = Cursors.Hand;
            pictureHelp.Location = new Point(897, 11);
            pictureHelp.Margin = new Padding(5, 3, 5, 3);
            pictureHelp.Name = "pictureHelp";
            pictureHelp.Size = new Size(32, 32);
            pictureHelp.TabIndex = 11;
            pictureHelp.TabStop = false;
            // 
            // labelBindings
            // 
            labelBindings.AutoSize = true;
            labelBindings.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            labelBindings.Location = new Point(56, 8);
            labelBindings.Name = "labelBindings";
            labelBindings.Size = new Size(114, 32);
            labelBindings.TabIndex = 0;
            labelBindings.Text = "Bindings";
            // 
            // panelBindings
            // 
            panelBindings.AutoSize = true;
            panelBindings.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            panelBindings.Controls.Add(tableBindings);
            panelBindings.Dock = DockStyle.Top;
            panelBindings.Location = new Point(15, 66);
            panelBindings.Name = "panelBindings";
            panelBindings.Padding = new Padding(0, 0, 11, 5);
            panelBindings.Size = new Size(949, 395);
            panelBindings.TabIndex = 1;
            panelBindings.TabStop = true;
            // 
            // tableBindings
            // 
            tableBindings.AccessibleRole = AccessibleRole.Table;
            tableBindings.AutoSize = true;
            tableBindings.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            tableBindings.ColumnCount = 3;
            tableBindings.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableBindings.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40F));
            tableBindings.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40F));
            tableBindings.Controls.Add(labelFNE, 0, 8);
            tableBindings.Controls.Add(comboFNE, 0, 8);
            tableBindings.Controls.Add(textFNE, 0, 8);
            tableBindings.Controls.Add(labelFNV, 0, 7);
            tableBindings.Controls.Add(comboFNV, 1, 7);
            tableBindings.Controls.Add(textFNV, 2, 7);
            tableBindings.Controls.Add(labelFNC, 0, 6);
            tableBindings.Controls.Add(comboFNC, 1, 6);
            tableBindings.Controls.Add(textFNC, 2, 6);
            tableBindings.Controls.Add(labelFNF4, 0, 5);
            tableBindings.Controls.Add(comboFNF4, 1, 5);
            tableBindings.Controls.Add(textFNF4, 2, 5);
            tableBindings.Controls.Add(comboM4, 1, 4);
            tableBindings.Controls.Add(textM4, 2, 4);
            tableBindings.Controls.Add(labelM4, 0, 4);
            tableBindings.Controls.Add(comboM5, 1, 3);
            tableBindings.Controls.Add(textM5, 2, 3);
            tableBindings.Controls.Add(labelM5, 0, 3);
            tableBindings.Controls.Add(comboM3, 1, 2);
            tableBindings.Controls.Add(textM3, 2, 2);
            tableBindings.Controls.Add(labelM3, 0, 2);
            tableBindings.Controls.Add(textM2, 2, 1);
            tableBindings.Controls.Add(labelM2, 0, 1);
            tableBindings.Controls.Add(comboM2, 1, 1);
            tableBindings.Controls.Add(textM1, 2, 0);
            tableBindings.Controls.Add(comboM1, 1, 0);
            tableBindings.Controls.Add(labelM1, 0, 0);
            tableBindings.Dock = DockStyle.Top;
            tableBindings.Location = new Point(0, 0);
            tableBindings.Margin = new Padding(0, 3, 5, 3);
            tableBindings.Name = "tableBindings";
            tableBindings.Padding = new Padding(16, 11, 0, 11);
            tableBindings.RowCount = 9;
            tableBindings.RowStyles.Add(new RowStyle());
            tableBindings.RowStyles.Add(new RowStyle());
            tableBindings.RowStyles.Add(new RowStyle());
            tableBindings.RowStyles.Add(new RowStyle());
            tableBindings.RowStyles.Add(new RowStyle());
            tableBindings.RowStyles.Add(new RowStyle());
            tableBindings.RowStyles.Add(new RowStyle());
            tableBindings.RowStyles.Add(new RowStyle());
            tableBindings.RowStyles.Add(new RowStyle());
            tableBindings.Size = new Size(938, 390);
            tableBindings.TabIndex = 12;
            // 
            // labelFNE
            // 
            labelFNE.AutoSize = true;
            labelFNE.Location = new Point(16, 333);
            labelFNE.Margin = new Padding(0);
            labelFNE.Name = "labelFNE";
            labelFNE.Padding = new Padding(5, 11, 0, 0);
            labelFNE.Size = new Size(143, 43);
            labelFNE.TabIndex = 20;
            labelFNE.Text = "FN+NmEnt:";
            // 
            // comboFNE
            // 
            comboFNE.BorderColor = Color.White;
            comboFNE.ButtonColor = Color.FromArgb(255, 255, 255);
            comboFNE.Dock = DockStyle.Top;
            comboFNE.FormattingEnabled = true;
            comboFNE.Location = new Point(205, 336);
            comboFNE.Margin = new Padding(5, 3, 5, 3);
            comboFNE.Name = "comboFNE";
            comboFNE.Size = new Size(358, 40);
            comboFNE.TabIndex = 8;
            // 
            // textFNE
            // 
            textFNE.Dock = DockStyle.Top;
            textFNE.Location = new Point(573, 336);
            textFNE.Margin = new Padding(5, 3, 5, 3);
            textFNE.Name = "textFNE";
            textFNE.PlaceholderText = "action";
            textFNE.Size = new Size(360, 39);
            textFNE.TabIndex = 19;
            textFNE.TabStop = false;
            // 
            // labelFNV
            // 
            labelFNV.AutoSize = true;
            labelFNV.Location = new Point(16, 287);
            labelFNV.Margin = new Padding(0);
            labelFNV.Name = "labelFNV";
            labelFNV.Padding = new Padding(5, 11, 0, 0);
            labelFNV.Size = new Size(85, 43);
            labelFNV.TabIndex = 15;
            labelFNV.Text = "FN+V:";
            // 
            // comboFNV
            // 
            comboFNV.BorderColor = Color.White;
            comboFNV.ButtonColor = Color.FromArgb(255, 255, 255);
            comboFNV.Dock = DockStyle.Top;
            comboFNV.FormattingEnabled = true;
            comboFNV.Location = new Point(205, 290);
            comboFNV.Margin = new Padding(5, 3, 5, 3);
            comboFNV.Name = "comboFNV";
            comboFNV.Size = new Size(358, 40);
            comboFNV.TabIndex = 7;
            // 
            // textFNV
            // 
            textFNV.Dock = DockStyle.Top;
            textFNV.Location = new Point(573, 290);
            textFNV.Margin = new Padding(5, 3, 5, 3);
            textFNV.Name = "textFNV";
            textFNV.PlaceholderText = "action";
            textFNV.Size = new Size(360, 39);
            textFNV.TabIndex = 18;
            textFNV.TabStop = false;
            // 
            // labelFNC
            // 
            labelFNC.AutoSize = true;
            labelFNC.Location = new Point(16, 241);
            labelFNC.Margin = new Padding(0);
            labelFNC.Name = "labelFNC";
            labelFNC.Padding = new Padding(5, 11, 0, 0);
            labelFNC.Size = new Size(85, 43);
            labelFNC.TabIndex = 15;
            labelFNC.Text = "FN+C:";
            // 
            // comboFNC
            // 
            comboFNC.BorderColor = Color.White;
            comboFNC.ButtonColor = Color.FromArgb(255, 255, 255);
            comboFNC.Dock = DockStyle.Top;
            comboFNC.FormattingEnabled = true;
            comboFNC.Location = new Point(205, 244);
            comboFNC.Margin = new Padding(5, 3, 5, 3);
            comboFNC.Name = "comboFNC";
            comboFNC.Size = new Size(358, 40);
            comboFNC.TabIndex = 6;
            // 
            // textFNC
            // 
            textFNC.Dock = DockStyle.Top;
            textFNC.Location = new Point(573, 244);
            textFNC.Margin = new Padding(5, 3, 5, 3);
            textFNC.Name = "textFNC";
            textFNC.PlaceholderText = "action";
            textFNC.Size = new Size(360, 39);
            textFNC.TabIndex = 17;
            textFNC.TabStop = false;
            // 
            // labelFNF4
            // 
            labelFNF4.AutoSize = true;
            labelFNF4.Location = new Point(16, 195);
            labelFNF4.Margin = new Padding(0);
            labelFNF4.Name = "labelFNF4";
            labelFNF4.Padding = new Padding(5, 11, 0, 0);
            labelFNF4.Size = new Size(95, 43);
            labelFNF4.TabIndex = 6;
            labelFNF4.Text = "FN+F4:";
            // 
            // comboFNF4
            // 
            comboFNF4.BorderColor = Color.White;
            comboFNF4.ButtonColor = Color.FromArgb(255, 255, 255);
            comboFNF4.Dock = DockStyle.Top;
            comboFNF4.FormattingEnabled = true;
            comboFNF4.Location = new Point(205, 198);
            comboFNF4.Margin = new Padding(5, 3, 5, 3);
            comboFNF4.Name = "comboFNF4";
            comboFNF4.Size = new Size(358, 40);
            comboFNF4.TabIndex = 5;
            // 
            // textFNF4
            // 
            textFNF4.Dock = DockStyle.Top;
            textFNF4.Location = new Point(573, 198);
            textFNF4.Margin = new Padding(5, 3, 5, 3);
            textFNF4.Name = "textFNF4";
            textFNF4.PlaceholderText = "action";
            textFNF4.Size = new Size(360, 39);
            textFNF4.TabIndex = 8;
            textFNF4.TabStop = false;
            // 
            // comboM4
            // 
            comboM4.BorderColor = Color.White;
            comboM4.ButtonColor = Color.FromArgb(255, 255, 255);
            comboM4.Dock = DockStyle.Top;
            comboM4.FormattingEnabled = true;
            comboM4.Items.AddRange(new object[] { Strings.PerformanceMode, Strings.OpenGHelper, Strings.Custom });
            comboM4.Location = new Point(205, 152);
            comboM4.Margin = new Padding(5, 3, 5, 3);
            comboM4.Name = "comboM4";
            comboM4.Size = new Size(358, 40);
            comboM4.TabIndex = 4;
            // 
            // textM4
            // 
            textM4.Dock = DockStyle.Top;
            textM4.Location = new Point(573, 152);
            textM4.Margin = new Padding(5, 3, 5, 3);
            textM4.Name = "textM4";
            textM4.PlaceholderText = "action";
            textM4.Size = new Size(360, 39);
            textM4.TabIndex = 5;
            textM4.TabStop = false;
            // 
            // labelM4
            // 
            labelM4.AutoSize = true;
            labelM4.Location = new Point(16, 149);
            labelM4.Margin = new Padding(0);
            labelM4.Name = "labelM4";
            labelM4.Padding = new Padding(5, 11, 0, 0);
            labelM4.Size = new Size(116, 43);
            labelM4.TabIndex = 2;
            labelM4.Text = "M4/ROG:";
            //
            // comboM5
            //
            comboM5.BorderColor = Color.White;
            comboM5.ButtonColor = Color.FromArgb(255, 255, 255);
            comboM5.Dock = DockStyle.Top;
            comboM5.FormattingEnabled = true;
            comboM5.Location = new Point(205, 152);
            comboM5.Margin = new Padding(5, 3, 5, 3);
            comboM5.Name = "comboM5";
            comboM5.Size = new Size(358, 40);
            comboM5.TabIndex = 6;
            //
            // textM5
            //
            textM5.Dock = DockStyle.Top;
            textM5.Location = new Point(573, 152);
            textM5.Margin = new Padding(5, 3, 5, 3);
            textM5.Name = "textM5";
            textM5.PlaceholderText = "action";
            textM5.Size = new Size(360, 39);
            textM5.TabIndex = 7;
            textM5.TabStop = false;
            //
            // labelM5
            //
            labelM5.AutoSize = true;
            labelM5.Location = new Point(16, 149);
            labelM5.Margin = new Padding(0);
            labelM5.Name = "labelM5";
            labelM5.Padding = new Padding(5, 11, 0, 0);
            labelM5.Size = new Size(59, 43);
            labelM5.TabIndex = 2;
            labelM5.Text = "M4:";
            //
            // comboM3
            //
            comboM3.BorderColor = Color.White;
            comboM3.ButtonColor = Color.FromArgb(255, 255, 255);
            comboM3.Dock = DockStyle.Top;
            comboM3.FormattingEnabled = true;
            comboM3.Items.AddRange(new object[] { Strings.Default, Strings.VolumeMute, Strings.PlayPause, Strings.PrintScreen, Strings.ToggleAura, Strings.Custom });
            comboM3.Location = new Point(205, 106);
            comboM3.Margin = new Padding(5, 3, 5, 3);
            comboM3.Name = "comboM3";
            comboM3.Size = new Size(358, 40);
            comboM3.TabIndex = 3;
            // 
            // textM3
            // 
            textM3.Dock = DockStyle.Top;
            textM3.Location = new Point(573, 106);
            textM3.Margin = new Padding(5, 3, 5, 3);
            textM3.Name = "textM3";
            textM3.PlaceholderText = "action";
            textM3.Size = new Size(360, 39);
            textM3.TabIndex = 4;
            textM3.TabStop = false;
            // 
            // labelM3
            // 
            labelM3.AutoSize = true;
            labelM3.Location = new Point(16, 103);
            labelM3.Margin = new Padding(0);
            labelM3.Name = "labelM3";
            labelM3.Padding = new Padding(5, 11, 0, 0);
            labelM3.Size = new Size(59, 43);
            labelM3.TabIndex = 0;
            labelM3.Text = "M3:";
            // 
            // textM2
            // 
            textM2.Dock = DockStyle.Top;
            textM2.Location = new Point(573, 60);
            textM2.Margin = new Padding(5, 3, 5, 3);
            textM2.Name = "textM2";
            textM2.PlaceholderText = "action";
            textM2.Size = new Size(360, 39);
            textM2.TabIndex = 14;
            textM2.TabStop = false;
            // 
            // labelM2
            // 
            labelM2.AutoSize = true;
            labelM2.Location = new Point(16, 57);
            labelM2.Margin = new Padding(0);
            labelM2.Name = "labelM2";
            labelM2.Padding = new Padding(5, 11, 0, 0);
            labelM2.Size = new Size(59, 43);
            labelM2.TabIndex = 10;
            labelM2.Text = "M2:";
            // 
            // comboM2
            // 
            comboM2.BorderColor = Color.White;
            comboM2.ButtonColor = Color.FromArgb(255, 255, 255);
            comboM2.Dock = DockStyle.Top;
            comboM2.FormattingEnabled = true;
            comboM2.Items.AddRange(new object[] { Strings.Default, Strings.VolumeMute, Strings.PlayPause, Strings.PrintScreen, Strings.ToggleAura, Strings.Custom });
            comboM2.Location = new Point(205, 60);
            comboM2.Margin = new Padding(5, 3, 5, 3);
            comboM2.Name = "comboM2";
            comboM2.Size = new Size(358, 40);
            comboM2.TabIndex = 2;
            // 
            // textM1
            // 
            textM1.Dock = DockStyle.Top;
            textM1.Location = new Point(573, 14);
            textM1.Margin = new Padding(5, 3, 5, 3);
            textM1.Name = "textM1";
            textM1.PlaceholderText = "action";
            textM1.Size = new Size(360, 39);
            textM1.TabIndex = 13;
            textM1.TabStop = false;
            // 
            // comboM1
            // 
            comboM1.BorderColor = Color.White;
            comboM1.ButtonColor = Color.FromArgb(255, 255, 255);
            comboM1.Dock = DockStyle.Top;
            comboM1.FormattingEnabled = true;
            comboM1.Items.AddRange(new object[] { Strings.Default, Strings.VolumeMute, Strings.PlayPause, Strings.PrintScreen, Strings.ToggleAura, Strings.Custom });
            comboM1.Location = new Point(205, 14);
            comboM1.Margin = new Padding(5, 3, 5, 3);
            comboM1.Name = "comboM1";
            comboM1.Size = new Size(358, 40);
            comboM1.TabIndex = 1;
            // 
            // labelM1
            // 
            labelM1.AutoSize = true;
            labelM1.Location = new Point(16, 11);
            labelM1.Margin = new Padding(0);
            labelM1.Name = "labelM1";
            labelM1.Padding = new Padding(5, 11, 0, 0);
            labelM1.Size = new Size(59, 43);
            labelM1.TabIndex = 9;
            labelM1.Text = "M1:";
            // 
            // tableKeys
            // 
            tableKeys.ColumnCount = 3;
            tableKeys.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableKeys.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40F));
            tableKeys.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40F));
            tableKeys.Location = new Point(0, 0);
            tableKeys.Name = "tableKeys";
            tableKeys.RowCount = 6;
            tableKeys.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableKeys.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableKeys.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableKeys.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableKeys.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableKeys.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableKeys.Size = new Size(200, 100);
            tableKeys.TabIndex = 0;
            // 
            // panelBacklightHeader
            // 
            panelBacklightHeader.AutoSize = true;
            panelBacklightHeader.BackColor = SystemColors.ControlLight;
            panelBacklightHeader.Controls.Add(sliderBrightness);
            panelBacklightHeader.Controls.Add(pictureBacklight);
            panelBacklightHeader.Controls.Add(labelBacklightTitle);
            panelBacklightHeader.Dock = DockStyle.Top;
            panelBacklightHeader.Location = new Point(15, 461);
            panelBacklightHeader.Name = "panelBacklightHeader";
            panelBacklightHeader.Padding = new Padding(11, 5, 11, 5);
            panelBacklightHeader.Size = new Size(949, 51);
            panelBacklightHeader.TabIndex = 2;
            // 
            // sliderBrightness
            // 
            sliderBrightness.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            sliderBrightness.Location = new Point(433, 5);
            sliderBrightness.Margin = new Padding(0);
            sliderBrightness.Max = 3;
            sliderBrightness.Min = 0;
            sliderBrightness.Name = "sliderBrightness";
            sliderBrightness.Size = new Size(501, 40);
            sliderBrightness.Step = 1;
            sliderBrightness.TabIndex = 50;
            sliderBrightness.TabStop = true;
            sliderBrightness.Text = "sliderBrightness";
            sliderBrightness.Value = 3;
            // 
            // pictureBacklight
            // 
            pictureBacklight.BackgroundImage = Resources.backlight;
            pictureBacklight.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBacklight.Location = new Point(21, 11);
            pictureBacklight.Name = "pictureBacklight";
            pictureBacklight.Size = new Size(32, 32);
            pictureBacklight.TabIndex = 3;
            pictureBacklight.TabStop = false;
            // 
            // labelBacklightTitle
            // 
            labelBacklightTitle.AutoSize = true;
            labelBacklightTitle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            labelBacklightTitle.Location = new Point(56, 8);
            labelBacklightTitle.Name = "labelBacklightTitle";
            labelBacklightTitle.Size = new Size(119, 32);
            labelBacklightTitle.TabIndex = 2;
            labelBacklightTitle.Text = "Backlight";
            // 
            // panelBacklight
            // 
            panelBacklight.AutoSize = true;
            panelBacklight.Controls.Add(panelBacklightExtra);
            panelBacklight.Controls.Add(panelXGM);
            panelBacklight.Controls.Add(tableBacklight);
            panelBacklight.Dock = DockStyle.Top;
            panelBacklight.Location = new Point(15, 512);
            panelBacklight.Name = "panelBacklight";
            panelBacklight.Padding = new Padding(0, 5, 0, 5);
            panelBacklight.Size = new Size(949, 444);
            panelBacklight.TabIndex = 3;
            // 
            // panelBacklightExtra
            // 
            panelBacklightExtra.AutoSize = true;
            panelBacklightExtra.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            panelBacklightExtra.Controls.Add(numericBacklightPluggedTime);
            panelBacklightExtra.Controls.Add(numericBacklightTime);
            panelBacklightExtra.Controls.Add(labelBacklightTimeout);
            panelBacklightExtra.Controls.Add(labelSpeed);
            panelBacklightExtra.Controls.Add(comboKeyboardSpeed);
            panelBacklightExtra.Dock = DockStyle.Top;
            panelBacklightExtra.Location = new Point(0, 324);
            panelBacklightExtra.Margin = new Padding(5, 3, 5, 3);
            panelBacklightExtra.Name = "panelBacklightExtra";
            panelBacklightExtra.Padding = new Padding(0, 0, 0, 5);
            panelBacklightExtra.Size = new Size(949, 115);
            panelBacklightExtra.TabIndex = 46;
            // 
            // numericBacklightPluggedTime
            // 
            numericBacklightPluggedTime.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            numericBacklightPluggedTime.Location = new Point(634, 63);
            numericBacklightPluggedTime.Margin = new Padding(5, 3, 5, 3);
            numericBacklightPluggedTime.Maximum = new decimal(new int[] { 3600, 0, 0, 0 });
            numericBacklightPluggedTime.Name = "numericBacklightPluggedTime";
            numericBacklightPluggedTime.Size = new Size(139, 39);
            numericBacklightPluggedTime.TabIndex = 1;
            numericBacklightPluggedTime.Unit = "sec";
            numericBacklightPluggedTime.UnitFirst = false;
            // 
            // numericBacklightTime
            // 
            numericBacklightTime.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            numericBacklightTime.Location = new Point(789, 63);
            numericBacklightTime.Margin = new Padding(5, 3, 5, 3);
            numericBacklightTime.Maximum = new decimal(new int[] { 3600, 0, 0, 0 });
            numericBacklightTime.Name = "numericBacklightTime";
            numericBacklightTime.Size = new Size(139, 39);
            numericBacklightTime.TabIndex = 2;
            numericBacklightTime.Unit = "sec";
            numericBacklightTime.UnitFirst = false;
            // 
            // labelBacklightTimeout
            // 
            labelBacklightTimeout.Location = new Point(16, 63);
            labelBacklightTimeout.Margin = new Padding(5, 0, 5, 0);
            labelBacklightTimeout.Name = "labelBacklightTimeout";
            labelBacklightTimeout.Size = new Size(613, 47);
            labelBacklightTimeout.TabIndex = 46;
            labelBacklightTimeout.Text = "Timeout when plugged / on battery";
            // 
            // labelSpeed
            // 
            labelSpeed.Location = new Point(16, 16);
            labelSpeed.Margin = new Padding(5, 0, 5, 0);
            labelSpeed.Name = "labelSpeed";
            labelSpeed.Size = new Size(613, 43);
            labelSpeed.TabIndex = 44;
            labelSpeed.Text = "Animation Speed";
            // 
            // comboKeyboardSpeed
            // 
            comboKeyboardSpeed.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            comboKeyboardSpeed.BorderColor = Color.White;
            comboKeyboardSpeed.ButtonColor = SystemColors.ControlLight;
            comboKeyboardSpeed.FlatStyle = FlatStyle.Flat;
            comboKeyboardSpeed.Font = new Font("Segoe UI", 9F);
            comboKeyboardSpeed.FormattingEnabled = true;
            comboKeyboardSpeed.Items.AddRange(new object[] { "Slow", "Normal", "Fast" });
            comboKeyboardSpeed.Location = new Point(634, 13);
            comboKeyboardSpeed.Margin = new Padding(5, 11, 5, 9);
            comboKeyboardSpeed.Name = "comboKeyboardSpeed";
            comboKeyboardSpeed.Size = new Size(293, 40);
            comboKeyboardSpeed.TabIndex = 0;
            comboKeyboardSpeed.TabStop = false;
            // 
            // panelXMG
            // 
            panelXGM.Controls.Add(checkXGM);
            panelXGM.Dock = DockStyle.Top;
            panelXGM.Location = new Point(0, 265);
            panelXGM.Margin = new Padding(5, 3, 5, 3);
            panelXGM.Name = "panelXMG";
            panelXGM.Size = new Size(949, 59);
            panelXGM.TabIndex = 45;
            // 
            // checkXMG
            // 
            checkXGM.AutoSize = true;
            checkXGM.Location = new Point(5, 11);
            checkXGM.Margin = new Padding(5, 3, 5, 3);
            checkXGM.Name = "checkXMG";
            checkXGM.Padding = new Padding(16, 3, 7, 3);
            checkXGM.Size = new Size(181, 42);
            checkXGM.TabIndex = 2;
            checkXGM.Text = "XG Mobile";
            checkXGM.UseVisualStyleBackColor = true;
            // 
            // tableBacklight
            // 
            tableBacklight.AutoSize = true;
            tableBacklight.ColumnCount = 5;
            tableBacklight.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            tableBacklight.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            tableBacklight.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            tableBacklight.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            tableBacklight.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            tableBacklight.Controls.Add(labelBacklightKeyboard, 0, 0);
            tableBacklight.Controls.Add(checkAwake, 1, 0);
            tableBacklight.Controls.Add(checkSleep, 2, 0);
            tableBacklight.Controls.Add(checkBoot, 3, 0);
            tableBacklight.Controls.Add(checkBattery, 4, 0);
            tableBacklight.Controls.Add(labelBacklightLogo, 0, 1);
            tableBacklight.Controls.Add(checkAwakeLogo, 1, 1);
            tableBacklight.Controls.Add(checkSleepLogo, 2, 1);
            tableBacklight.Controls.Add(checkBootLogo, 3, 1);
            tableBacklight.Controls.Add(checkBatteryLogo, 4, 1);
            tableBacklight.Controls.Add(labelBacklightBar, 0, 2);
            tableBacklight.Controls.Add(checkAwakeBar, 1, 2);
            tableBacklight.Controls.Add(checkSleepBar, 2, 2);
            tableBacklight.Controls.Add(checkBootBar, 3, 2);
            tableBacklight.Controls.Add(checkBatteryBar, 4, 2);
            tableBacklight.Controls.Add(labelBacklightLid, 0, 3);
            tableBacklight.Controls.Add(checkAwakeLid, 1, 3);
            tableBacklight.Controls.Add(checkSleepLid, 2, 3);
            tableBacklight.Controls.Add(checkBootLid, 3, 3);
            tableBacklight.Controls.Add(checkBatteryLid, 4, 3);
            tableBacklight.Dock = DockStyle.Top;
            tableBacklight.Location = new Point(0, 5);
            tableBacklight.Margin = new Padding(0);
            tableBacklight.Name = "tableBacklight";
            tableBacklight.RowCount = 4;
            tableBacklight.RowStyles.Add(new RowStyle());
            tableBacklight.RowStyles.Add(new RowStyle());
            tableBacklight.RowStyles.Add(new RowStyle());
            tableBacklight.RowStyles.Add(new RowStyle());
            tableBacklight.Size = new Size(949, 172);
            tableBacklight.TabIndex = 44;
            // 
            // labelBacklightKeyboard
            // 
            labelBacklightKeyboard.Anchor = AnchorStyles.Left;
            labelBacklightKeyboard.AutoSize = true;
            labelBacklightKeyboard.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            labelBacklightKeyboard.Location = new Point(5, 0);
            labelBacklightKeyboard.Margin = new Padding(5, 0, 5, 0);
            labelBacklightKeyboard.Name = "labelBacklightKeyboard";
            labelBacklightKeyboard.Padding = new Padding(9, 5, 7, 5);
            labelBacklightKeyboard.Size = new Size(227, 45);
            labelBacklightKeyboard.TabIndex = 6;
            labelBacklightKeyboard.Text = "Keyboard";
            // 
            // checkAwake
            // 
            checkAwake.AutoSize = true;
            checkAwake.Location = new Point(5, 45);
            checkAwake.Margin = new Padding(5, 0, 5, 0);
            checkAwake.Name = "checkAwake";
            checkAwake.Padding = new Padding(16, 3, 7, 3);
            checkAwake.Size = new Size(227, 43);
            checkAwake.TabIndex = 1;
            checkAwake.Text = Strings.Awake;
            checkAwake.UseVisualStyleBackColor = true;
            // 
            // checkBoot
            // 
            checkBoot.AutoSize = true;
            checkBoot.Location = new Point(5, 88);
            checkBoot.Margin = new Padding(5, 0, 5, 0);
            checkBoot.Name = "checkBoot";
            checkBoot.Padding = new Padding(16, 3, 7, 3);
            checkBoot.Size = new Size(227, 43);
            checkBoot.TabIndex = 2;
            checkBoot.Text = Strings.Boot;
            checkBoot.UseVisualStyleBackColor = true;
            // 
            // checkSleep
            // 
            checkSleep.AutoSize = true;
            checkSleep.Location = new Point(5, 131);
            checkSleep.Margin = new Padding(5, 0, 5, 0);
            checkSleep.Name = "checkSleep";
            checkSleep.Padding = new Padding(16, 3, 7, 3);
            checkSleep.Size = new Size(227, 43);
            checkSleep.TabIndex = 3;
            checkSleep.Text = "Sleep";
            checkSleep.UseVisualStyleBackColor = true;
            // 
            // checkBattery
            // 
            checkBattery.AutoSize = true;
            checkBattery.Location = new Point(5, 174);
            checkBattery.Margin = new Padding(5, 0, 5, 0);
            checkBattery.Name = "checkBattery";
            checkBattery.Padding = new Padding(16, 3, 7, 3);
            checkBattery.Size = new Size(227, 43);
            checkBattery.TabIndex = 24;
            checkBattery.Text = "Battery";
            checkBattery.UseVisualStyleBackColor = true;
            // 
            // labelBacklightLogo
            // 
            labelBacklightLogo.Anchor = AnchorStyles.Left;
            labelBacklightLogo.AutoSize = true;
            labelBacklightLogo.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            labelBacklightLogo.Location = new Point(242, 0);
            labelBacklightLogo.Margin = new Padding(5, 0, 5, 0);
            labelBacklightLogo.Name = "labelBacklightLogo";
            labelBacklightLogo.Padding = new Padding(9, 5, 7, 5);
            labelBacklightLogo.Size = new Size(227, 45);
            labelBacklightLogo.TabIndex = 21;
            labelBacklightLogo.Text = "Logo";
            // 
            // checkAwakeLogo
            // 
            checkAwakeLogo.AutoSize = true;
            checkAwakeLogo.Location = new Point(242, 45);
            checkAwakeLogo.Margin = new Padding(5, 0, 5, 0);
            checkAwakeLogo.Name = "checkAwakeLogo";
            checkAwakeLogo.Padding = new Padding(16, 3, 7, 3);
            checkAwakeLogo.Size = new Size(227, 43);
            checkAwakeLogo.TabIndex = 17;
            checkAwakeLogo.Text = Strings.Awake;
            checkAwakeLogo.UseVisualStyleBackColor = true;
            // 
            // checkBootLogo
            // 
            checkBootLogo.AutoSize = true;
            checkBootLogo.Location = new Point(242, 88);
            checkBootLogo.Margin = new Padding(5, 0, 5, 0);
            checkBootLogo.Name = "checkBootLogo";
            checkBootLogo.Padding = new Padding(16, 3, 7, 3);
            checkBootLogo.Size = new Size(227, 43);
            checkBootLogo.TabIndex = 18;
            checkBootLogo.Text = Strings.Boot;
            checkBootLogo.UseVisualStyleBackColor = true;
            // 
            // checkSleepLogo
            // 
            checkSleepLogo.AutoSize = true;
            checkSleepLogo.Location = new Point(242, 131);
            checkSleepLogo.Margin = new Padding(5, 0, 5, 0);
            checkSleepLogo.Name = "checkSleepLogo";
            checkSleepLogo.Padding = new Padding(16, 3, 7, 3);
            checkSleepLogo.Size = new Size(227, 43);
            checkSleepLogo.TabIndex = 19;
            checkSleepLogo.Text = Strings.Sleep;
            checkSleepLogo.UseVisualStyleBackColor = true;
            // 
            // checkBatteryLogo
            // 
            checkBatteryLogo.AutoSize = true;
            checkBatteryLogo.Location = new Point(242, 174);
            checkBatteryLogo.Margin = new Padding(5, 0, 5, 0);
            checkBatteryLogo.Name = "checkBatteryLogo";
            checkBatteryLogo.Padding = new Padding(16, 3, 7, 3);
            checkBatteryLogo.Size = new Size(227, 43);
            checkBatteryLogo.TabIndex = 25;
            checkBatteryLogo.Text = "Battery";
            checkBatteryLogo.UseVisualStyleBackColor = true;
            // 
            // labelBacklightBar
            // 
            labelBacklightBar.Anchor = AnchorStyles.Left;
            labelBacklightBar.AutoSize = true;
            labelBacklightBar.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            labelBacklightBar.Location = new Point(479, 0);
            labelBacklightBar.Margin = new Padding(5, 0, 5, 0);
            labelBacklightBar.Name = "labelBacklightBar";
            labelBacklightBar.Padding = new Padding(9, 5, 7, 5);
            labelBacklightBar.Size = new Size(227, 45);
            labelBacklightBar.TabIndex = 11;
            labelBacklightBar.Text = "Lightbar";
            // 
            // checkAwakeBar
            // 
            checkAwakeBar.AutoSize = true;
            checkAwakeBar.Location = new Point(479, 45);
            checkAwakeBar.Margin = new Padding(5, 0, 5, 0);
            checkAwakeBar.Name = "checkAwakeBar";
            checkAwakeBar.Padding = new Padding(16, 3, 7, 3);
            checkAwakeBar.Size = new Size(227, 43);
            checkAwakeBar.TabIndex = 7;
            checkAwakeBar.Text = Strings.Awake;
            checkAwakeBar.UseVisualStyleBackColor = true;
            // 
            // checkBootBar
            // 
            checkBootBar.AutoSize = true;
            checkBootBar.Location = new Point(479, 88);
            checkBootBar.Margin = new Padding(5, 0, 5, 0);
            checkBootBar.Name = "checkBootBar";
            checkBootBar.Padding = new Padding(16, 3, 7, 3);
            checkBootBar.Size = new Size(227, 43);
            checkBootBar.TabIndex = 8;
            checkBootBar.Text = Strings.Boot;
            checkBootBar.UseVisualStyleBackColor = true;
            // 
            // checkSleepBar
            // 
            checkSleepBar.AutoSize = true;
            checkSleepBar.Location = new Point(479, 131);
            checkSleepBar.Margin = new Padding(5, 0, 5, 0);
            checkSleepBar.Name = "checkSleepBar";
            checkSleepBar.Padding = new Padding(16, 3, 7, 3);
            checkSleepBar.Size = new Size(227, 43);
            checkSleepBar.TabIndex = 9;
            checkSleepBar.Text = Strings.Sleep;
            checkSleepBar.UseVisualStyleBackColor = true;
            // 
            // checkBatteryBar
            // 
            checkBatteryBar.AutoSize = true;
            checkBatteryBar.Location = new Point(479, 174);
            checkBatteryBar.Margin = new Padding(5, 0, 5, 0);
            checkBatteryBar.Name = "checkBatteryBar";
            checkBatteryBar.Padding = new Padding(16, 3, 7, 3);
            checkBatteryBar.Size = new Size(227, 43);
            checkBatteryBar.TabIndex = 22;
            checkBatteryBar.Text = "Battery";
            checkBatteryBar.UseVisualStyleBackColor = true;
            // 
            // labelBacklightLid
            // 
            labelBacklightLid.Anchor = AnchorStyles.Left;
            labelBacklightLid.AutoSize = true;
            labelBacklightLid.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            labelBacklightLid.Location = new Point(716, 0);
            labelBacklightLid.Margin = new Padding(5, 0, 5, 0);
            labelBacklightLid.Name = "labelBacklightLid";
            labelBacklightLid.Padding = new Padding(9, 5, 7, 5);
            labelBacklightLid.Size = new Size(228, 45);
            labelBacklightLid.TabIndex = 16;
            labelBacklightLid.Text = "Lid";
            // 
            // checkAwakeLid
            // 
            checkAwakeLid.AutoSize = true;
            checkAwakeLid.Location = new Point(716, 45);
            checkAwakeLid.Margin = new Padding(5, 0, 5, 0);
            checkAwakeLid.Name = "checkAwakeLid";
            checkAwakeLid.Padding = new Padding(16, 3, 7, 3);
            checkAwakeLid.Size = new Size(228, 43);
            checkAwakeLid.TabIndex = 12;
            checkAwakeLid.Text = Strings.Awake;
            checkAwakeLid.UseVisualStyleBackColor = true;
            // 
            // checkBootLid
            // 
            checkBootLid.AutoSize = true;
            checkBootLid.Location = new Point(716, 88);
            checkBootLid.Margin = new Padding(5, 0, 5, 0);
            checkBootLid.Name = "checkBootLid";
            checkBootLid.Padding = new Padding(16, 3, 7, 3);
            checkBootLid.Size = new Size(228, 43);
            checkBootLid.TabIndex = 13;
            checkBootLid.Text = Strings.Boot;
            checkBootLid.UseVisualStyleBackColor = true;
            // 
            // checkSleepLid
            // 
            checkSleepLid.AutoSize = true;
            checkSleepLid.Location = new Point(716, 131);
            checkSleepLid.Margin = new Padding(5, 0, 5, 0);
            checkSleepLid.Name = "checkSleepLid";
            checkSleepLid.Padding = new Padding(16, 3, 7, 3);
            checkSleepLid.Size = new Size(228, 43);
            checkSleepLid.TabIndex = 14;
            checkSleepLid.Text = Strings.Sleep;
            checkSleepLid.UseVisualStyleBackColor = true;
            // 
            // checkBatteryLid
            // 
            checkBatteryLid.AutoSize = true;
            checkBatteryLid.Location = new Point(716, 174);
            checkBatteryLid.Margin = new Padding(5, 0, 5, 0);
            checkBatteryLid.Name = "checkBatteryLid";
            checkBatteryLid.Padding = new Padding(16, 3, 7, 3);
            checkBatteryLid.Size = new Size(228, 43);
            checkBatteryLid.TabIndex = 23;
            checkBatteryLid.Text = "Battery";
            checkBatteryLid.UseVisualStyleBackColor = true;
            // 
            // panelSettingsHeader
            // 
            panelSettingsHeader.AutoSize = true;
            panelSettingsHeader.BackColor = SystemColors.ControlLight;
            panelSettingsHeader.Controls.Add(pictureScan);
            panelSettingsHeader.Controls.Add(pictureLog);
            panelSettingsHeader.Controls.Add(pictureSettings);
            panelSettingsHeader.Controls.Add(labelSettings);
            panelSettingsHeader.Dock = DockStyle.Top;
            panelSettingsHeader.Location = new Point(15, 956);
            panelSettingsHeader.Name = "panelSettingsHeader";
            panelSettingsHeader.Padding = new Padding(11, 5, 11, 5);
            panelSettingsHeader.Size = new Size(949, 51);
            panelSettingsHeader.TabIndex = 45;
            // 
            // pictureScan
            // 
            pictureScan.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pictureScan.BackgroundImage = Resources.icons8_search_32;
            pictureScan.BackgroundImageLayout = ImageLayout.Zoom;
            pictureScan.Cursor = Cursors.Hand;
            pictureScan.Location = new Point(857, 11);
            pictureScan.Margin = new Padding(5, 3, 5, 3);
            pictureScan.Name = "pictureScan";
            pictureScan.Size = new Size(32, 32);
            pictureScan.TabIndex = 13;
            pictureScan.TabStop = false;
            pictureScan.Visible = false;
            // 
            // pictureLog
            // 
            pictureLog.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pictureLog.BackgroundImage = Resources.icons8_log_32;
            pictureLog.BackgroundImageLayout = ImageLayout.Zoom;
            pictureLog.Cursor = Cursors.Hand;
            pictureLog.Location = new Point(897, 11);
            pictureLog.Margin = new Padding(5, 3, 5, 3);
            pictureLog.Name = "pictureLog";
            pictureLog.Size = new Size(32, 32);
            pictureLog.TabIndex = 12;
            pictureLog.TabStop = false;
            // 
            // pictureSettings
            // 
            pictureSettings.BackgroundImage = Resources.icons8_settings_32;
            pictureSettings.BackgroundImageLayout = ImageLayout.Zoom;
            pictureSettings.Location = new Point(21, 11);
            pictureSettings.Name = "pictureSettings";
            pictureSettings.Size = new Size(32, 32);
            pictureSettings.TabIndex = 1;
            pictureSettings.TabStop = false;
            // 
            // labelSettings
            // 
            labelSettings.AutoSize = true;
            labelSettings.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            labelSettings.Location = new Point(56, 9);
            labelSettings.Name = "labelSettings";
            labelSettings.Size = new Size(78, 32);
            labelSettings.TabIndex = 0;
            labelSettings.Text = "Other";
            // 
            // panelSettings
            // 
            panelSettings.AccessibleRole = AccessibleRole.Grouping;
            panelSettings.AutoSize = true;
            panelSettings.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            panelSettings.Controls.Add(checkELMB);
            panelSettings.Controls.Add(checkAutoToggleClamshellMode);
            panelSettings.Controls.Add(checkTopmost);
            panelSettings.Controls.Add(checkNoOverdrive);
            panelSettings.Controls.Add(checkKeystoneSound);
            panelSettings.Controls.Add(checkBootSound);
            panelSettings.Controls.Add(checkUSBC);
            panelSettings.Controls.Add(checkGpuApps);
            panelSettings.Controls.Add(checkNVPlatform);
            panelSettings.Controls.Add(checkNumberPad);
            panelSettings.Controls.Add(checkStatusLed);
            panelSettings.Controls.Add(checkStandbyNetworking);
            panelSettings.Controls.Add(checkAspm);
            panelSettings.Dock = DockStyle.Top;
            panelSettings.Location = new Point(15, 1252);
            panelSettings.Name = "panelSettings";
            panelSettings.Padding = new Padding(21, 5, 11, 5);
            panelSettings.Size = new Size(949, 514);
            panelSettings.TabIndex = 50;
            // 
            // checkELMB
            // 
            checkELMB.AutoSize = true;
            checkELMB.Dock = DockStyle.Top;
            checkELMB.Location = new Point(21, 467);
            checkELMB.Margin = new Padding(5, 3, 5, 3);
            checkELMB.Name = "checkELMB";
            checkELMB.Padding = new Padding(3);
            checkELMB.Size = new Size(917, 42);
            checkELMB.TabIndex = 10;
            checkELMB.Text = Strings.ExtremeLowMotionBlur;
            checkELMB.UseVisualStyleBackColor = true;
            // 
            // checkAutoToggleClamshellMode
            // 
            checkAutoToggleClamshellMode.AutoSize = true;
            checkAutoToggleClamshellMode.Dock = DockStyle.Top;
            checkAutoToggleClamshellMode.Location = new Point(21, 425);
            checkAutoToggleClamshellMode.Name = "checkAutoToggleClamshellMode";
            checkAutoToggleClamshellMode.Padding = new Padding(3);
            checkAutoToggleClamshellMode.Size = new Size(917, 42);
            checkAutoToggleClamshellMode.TabIndex = 9;
            checkAutoToggleClamshellMode.Text = "Auto Toggle Clamshell Mode";
            checkAutoToggleClamshellMode.UseVisualStyleBackColor = true;
            //
            // checkTopmost
            // 
            checkTopmost.AutoSize = true;
            checkTopmost.Dock = DockStyle.Top;
            checkTopmost.Location = new Point(21, 341);
            checkTopmost.Margin = new Padding(5, 3, 5, 3);
            checkTopmost.Name = "checkTopmost";
            checkTopmost.Padding = new Padding(3);
            checkTopmost.Size = new Size(917, 42);
            checkTopmost.TabIndex = 8;
            checkTopmost.Text = Strings.WindowTop;
            checkTopmost.UseVisualStyleBackColor = true;
            // 
            // checkNoOverdrive
            // 
            checkNoOverdrive.AutoSize = true;
            checkNoOverdrive.Dock = DockStyle.Top;
            checkNoOverdrive.Location = new Point(21, 299);
            checkNoOverdrive.Margin = new Padding(5, 3, 5, 3);
            checkNoOverdrive.Name = "checkNoOverdrive";
            checkNoOverdrive.Padding = new Padding(3);
            checkNoOverdrive.Size = new Size(917, 42);
            checkNoOverdrive.TabIndex = 7;
            checkNoOverdrive.Text = Strings.DisableOverdrive;
            checkNoOverdrive.UseVisualStyleBackColor = true;
            // 
            // checkBootSound
            // 
            checkBootSound.AutoSize = true;
            checkBootSound.Dock = DockStyle.Top;
            checkBootSound.Location = new Point(21, 257);
            checkBootSound.Margin = new Padding(5, 3, 5, 3);
            checkBootSound.Name = "checkBootSound";
            checkBootSound.Padding = new Padding(3);
            checkBootSound.Size = new Size(917, 42);
            checkBootSound.TabIndex = 5;
            checkBootSound.Text = "Boot Sound";
            checkBootSound.UseVisualStyleBackColor = true;
            //
            // checkKeystoneSound
            //
            checkKeystoneSound.AutoSize = true;
            checkKeystoneSound.Dock = DockStyle.Top;
            checkKeystoneSound.Location = new Point(21, 299);
            checkKeystoneSound.Margin = new Padding(5, 3, 5, 3);
            checkKeystoneSound.Name = "checkKeystoneSound";
            checkKeystoneSound.Padding = new Padding(3);
            checkKeystoneSound.Size = new Size(917, 42);
            checkKeystoneSound.TabIndex = 6;
            checkKeystoneSound.Text = "Keystone Sound";
            checkKeystoneSound.UseVisualStyleBackColor = true;
            checkKeystoneSound.Visible = false;
            // 
            // checkUSBC
            // 
            checkUSBC.AutoSize = true;
            checkUSBC.Dock = DockStyle.Top;
            checkUSBC.Location = new Point(21, 215);
            checkUSBC.Margin = new Padding(5, 3, 5, 3);
            checkUSBC.Name = "checkUSBC";
            checkUSBC.Padding = new Padding(3);
            checkUSBC.Size = new Size(917, 42);
            checkUSBC.TabIndex = 4;
            checkUSBC.Text = "Keep GPU disabled on USB-C charger in Optimized mode";
            checkUSBC.UseVisualStyleBackColor = true;
            // 
            // checkGpuApps
            // 
            checkGpuApps.AutoSize = true;
            checkGpuApps.Dock = DockStyle.Top;
            checkGpuApps.Location = new Point(21, 173);
            checkGpuApps.Margin = new Padding(5, 3, 5, 3);
            checkGpuApps.Name = "checkGpuApps";
            checkGpuApps.Padding = new Padding(3);
            checkGpuApps.Size = new Size(917, 42);
            checkGpuApps.TabIndex = 3;
            checkGpuApps.Text = "Stop all apps using GPU when switching to Eco";
            checkGpuApps.UseVisualStyleBackColor = true;
            //
            // checkNVPlatform
            // 
            checkNVPlatform.AutoSize = true;
            checkNVPlatform.Dock = DockStyle.Top;
            checkNVPlatform.Location = new Point(21, 89);
            checkNVPlatform.Margin = new Padding(5, 3, 5, 3);
            checkNVPlatform.Name = "checkNVPlatform";
            checkNVPlatform.Padding = new Padding(3);
            checkNVPlatform.Size = new Size(917, 42);
            checkNVPlatform.TabIndex = 2;
            checkNVPlatform.Text = "Stop/Start NVIDIA services based on dGPU state";
            checkNVPlatform.UseVisualStyleBackColor = true;
            // 
            // checkStatusLed
            // 
            checkStatusLed.AutoSize = true;
            checkStatusLed.Dock = DockStyle.Top;
            checkStatusLed.Location = new Point(21, 47);
            checkStatusLed.Margin = new Padding(5, 3, 5, 3);
            checkStatusLed.Name = "checkStatusLed";
            checkStatusLed.Padding = new Padding(3);
            checkStatusLed.Size = new Size(917, 42);
            checkStatusLed.TabIndex = 1;
            checkStatusLed.Text = "LED Status Indicators";
            checkStatusLed.UseVisualStyleBackColor = true;
            checkStatusLed.Visible = false;
            //
            // checkNumberPad
            //
            checkNumberPad.AutoSize = true;
            checkNumberPad.Dock = DockStyle.Top;
            checkNumberPad.Location = new Point(21, 89);
            checkNumberPad.Margin = new Padding(5, 3, 5, 3);
            checkNumberPad.Name = "checkNumberPad";
            checkNumberPad.Padding = new Padding(3);
            checkNumberPad.Size = new Size(917, 42);
            checkNumberPad.TabIndex = 10;
            checkNumberPad.Text = "Touchpad NumberPad";
            checkNumberPad.UseVisualStyleBackColor = true;
            checkNumberPad.Visible = false;
            //
            // checkAspm
            //
            checkAspm.AutoSize = true;
            checkAspm.Dock = DockStyle.Top;
            checkAspm.Location = new Point(21, 5);
            checkAspm.Margin = new Padding(5, 3, 5, 3);
            checkAspm.Name = "checkAspm";
            checkAspm.Padding = new Padding(3);
            checkAspm.Size = new Size(917, 42);
            checkAspm.TabIndex = 0;
            checkAspm.Text = "Disable PCIe Link State Management (plugged in)";
            checkAspm.UseVisualStyleBackColor = true;
            checkAspm.Visible = true;
            //
            // checkStandbyNetworking
            //
            checkStandbyNetworking.AutoSize = true;
            checkStandbyNetworking.Dock = DockStyle.Top;
            checkStandbyNetworking.Location = new Point(21, 47);
            checkStandbyNetworking.Margin = new Padding(5, 3, 5, 3);
            checkStandbyNetworking.Name = "checkStandbyNetworking";
            checkStandbyNetworking.Padding = new Padding(3);
            checkStandbyNetworking.Size = new Size(917, 42);
            checkStandbyNetworking.TabIndex = 1;
            checkStandbyNetworking.Text = "Disable networking in Modern Standby";
            checkStandbyNetworking.UseVisualStyleBackColor = true;
            checkStandbyNetworking.Visible = true;
            // 
            // panelPower
            // 
            panelPower.Controls.Add(numericHibernateAfter);
            panelPower.Controls.Add(labelHibernateAfter);
            panelPower.Controls.Add(pictureHibernate);
            panelPower.Dock = DockStyle.Top;
            panelPower.Location = new Point(15, 1724);
            panelPower.Name = "panelPower";
            panelPower.Size = new Size(949, 54);
            panelPower.TabIndex = 4;
            // 
            // numericHibernateAfter
            // 
            numericHibernateAfter.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            numericHibernateAfter.Increment = new decimal(new int[] { 10, 0, 0, 0 });
            numericHibernateAfter.Location = new Point(776, 7);
            numericHibernateAfter.Margin = new Padding(5, 3, 5, 3);
            numericHibernateAfter.Maximum = new decimal(new int[] { 3000000, 0, 0, 0 });
            numericHibernateAfter.Name = "numericHibernateAfter";
            numericHibernateAfter.Size = new Size(152, 39);
            numericHibernateAfter.TabIndex = 1;
            numericHibernateAfter.Unit = "min";
            numericHibernateAfter.UnitFirst = false;
            // 
            // labelHibernateAfter
            // 
            labelHibernateAfter.AutoSize = true;
            labelHibernateAfter.Location = new Point(59, 10);
            labelHibernateAfter.Margin = new Padding(5, 0, 5, 0);
            labelHibernateAfter.Name = "labelHibernateAfter";
            labelHibernateAfter.Size = new Size(457, 32);
            labelHibernateAfter.TabIndex = 45;
            labelHibernateAfter.Text = "Minutes till Hibernation in sleep (0 - OFF)";
            // 
            // pictureHibernate
            // 
            pictureHibernate.BackgroundImage = Resources.icons8_hibernate_32;
            pictureHibernate.BackgroundImageLayout = ImageLayout.Zoom;
            pictureHibernate.Location = new Point(21, 10);
            pictureHibernate.Name = "pictureHibernate";
            pictureHibernate.Size = new Size(32, 32);
            pictureHibernate.TabIndex = 22;
            pictureHibernate.TabStop = false;
            // 
            // panelAPU
            // 
            panelAPU.AutoSize = true;
            panelAPU.Controls.Add(comboAPU);
            panelAPU.Controls.Add(pictureAPUMem);
            panelAPU.Controls.Add(labelAPUMem);
            panelAPU.Dock = DockStyle.Top;
            panelAPU.Location = new Point(15, 1135);
            panelAPU.Name = "panelAPU";
            panelAPU.Padding = new Padding(11, 5, 11, 0);
            panelAPU.Size = new Size(949, 57);
            panelAPU.TabIndex = 46;
            panelAPU.Visible = false;
            panelAPU.Paint += panelAPU_Paint;
            // 
            // comboAPU
            // 
            comboAPU.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            comboAPU.BorderColor = Color.White;
            comboAPU.ButtonColor = SystemColors.ControlLight;
            comboAPU.FlatStyle = FlatStyle.Flat;
            comboAPU.Font = new Font("Segoe UI", 9F);
            comboAPU.FormattingEnabled = true;
            comboAPU.Items.AddRange(new object[] { "Auto", "1G", "2G", "3G", "4G", "5G", "6G", "7G", "8G" });
            comboAPU.Location = new Point(618, 8);
            comboAPU.Margin = new Padding(5, 11, 5, 9);
            comboAPU.Name = "comboAPU";
            comboAPU.Size = new Size(309, 40);
            comboAPU.TabIndex = 12;
            comboAPU.TabStop = false;
            // 
            // pictureAPUMem
            // 
            pictureAPUMem.BackgroundImage = Resources.icons8_video_48;
            pictureAPUMem.BackgroundImageLayout = ImageLayout.Zoom;
            pictureAPUMem.Location = new Point(21, 11);
            pictureAPUMem.Name = "pictureAPUMem";
            pictureAPUMem.Size = new Size(32, 32);
            pictureAPUMem.TabIndex = 1;
            pictureAPUMem.TabStop = false;
            // 
            // labelAPUMem
            // 
            labelAPUMem.AutoSize = true;
            labelAPUMem.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            labelAPUMem.Location = new Point(64, 11);
            labelAPUMem.Name = "labelAPUMem";
            labelAPUMem.Size = new Size(309, 32);
            labelAPUMem.TabIndex = 0;
            labelAPUMem.Text = "Memory assigned to iGPU";
            // 
            // panelCores
            // 
            panelCores.AutoSize = true;
            panelCores.Controls.Add(buttonCores);
            panelCores.Controls.Add(comboCoresP);
            panelCores.Controls.Add(comboCoresE);
            panelCores.Controls.Add(pictureCores);
            panelCores.Controls.Add(labelCores);
            panelCores.Dock = DockStyle.Top;
            panelCores.Location = new Point(15, 1076);
            panelCores.Name = "panelCores";
            panelCores.Padding = new Padding(11, 5, 11, 0);
            panelCores.Size = new Size(949, 59);
            panelCores.TabIndex = 47;
            panelCores.Visible = false;
            // 
            // buttonCores
            // 
            buttonCores.Activated = false;
            buttonCores.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            buttonCores.BackColor = SystemColors.ButtonHighlight;
            buttonCores.BorderColor = Color.Transparent;
            buttonCores.BorderRadius = 2;
            buttonCores.FlatStyle = FlatStyle.Flat;
            buttonCores.Location = new Point(831, 7);
            buttonCores.Margin = new Padding(5, 3, 5, 3);
            buttonCores.Name = "buttonCores";
            buttonCores.Secondary = false;
            buttonCores.Size = new Size(106, 48);
            buttonCores.TabIndex = 20;
            buttonCores.Text = "Apply";
            buttonCores.UseVisualStyleBackColor = false;
            // 
            // comboCoresP
            // 
            comboCoresP.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            comboCoresP.BorderColor = Color.White;
            comboCoresP.ButtonColor = SystemColors.ControlLight;
            comboCoresP.FlatStyle = FlatStyle.Flat;
            comboCoresP.Font = new Font("Segoe UI", 9F);
            comboCoresP.FormattingEnabled = true;
            comboCoresP.Location = new Point(513, 10);
            comboCoresP.Margin = new Padding(5, 11, 5, 9);
            comboCoresP.Name = "comboCoresP";
            comboCoresP.Size = new Size(150, 40);
            comboCoresP.TabIndex = 13;
            comboCoresP.TabStop = false;
            // 
            // comboCoresE
            // 
            comboCoresE.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            comboCoresE.BorderColor = Color.White;
            comboCoresE.ButtonColor = SystemColors.ControlLight;
            comboCoresE.FlatStyle = FlatStyle.Flat;
            comboCoresE.Font = new Font("Segoe UI", 9F);
            comboCoresE.FormattingEnabled = true;
            comboCoresE.Location = new Point(674, 10);
            comboCoresE.Margin = new Padding(5, 11, 5, 9);
            comboCoresE.Name = "comboCoresE";
            comboCoresE.Size = new Size(150, 40);
            comboCoresE.TabIndex = 12;
            comboCoresE.TabStop = false;
            // 
            // pictureCores
            // 
            pictureCores.BackgroundImage = Resources.icons8_processor_32;
            pictureCores.BackgroundImageLayout = ImageLayout.Zoom;
            pictureCores.Location = new Point(21, 15);
            pictureCores.Name = "pictureCores";
            pictureCores.Size = new Size(32, 32);
            pictureCores.TabIndex = 1;
            pictureCores.TabStop = false;
            //
            // labelCores
            //
            labelCores.AutoSize = true;
            labelCores.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            labelCores.Location = new Point(64, 14);
            labelCores.Name = "labelCores";
            labelCores.Size = new Size(299, 32);
            labelCores.TabIndex = 0;
            labelCores.Text = "CPU Cores Configuration";
            // 
            // panelACPI
            // 
            panelACPI.AutoSize = true;
            panelACPI.Controls.Add(textACPIParam);
            panelACPI.Controls.Add(textACPICommand);
            panelACPI.Controls.Add(buttonACPISend);
            panelACPI.Controls.Add(pictureDebug);
            panelACPI.Controls.Add(labelACPITitle);
            panelACPI.Dock = DockStyle.Top;
            panelACPI.Location = new Point(15, 1007);
            panelACPI.Name = "panelACPI";
            panelACPI.Padding = new Padding(11, 5, 11, 0);
            panelACPI.Size = new Size(949, 69);
            panelACPI.TabIndex = 48;
            panelACPI.Visible = false;
            // 
            // textACPIParam
            // 
            textACPIParam.Location = new Point(717, 18);
            textACPIParam.Margin = new Padding(5, 3, 5, 3);
            textACPIParam.Name = "textACPIParam";
            textACPIParam.PlaceholderText = "Value";
            textACPIParam.Size = new Size(127, 39);
            textACPIParam.TabIndex = 22;
            textACPIParam.TabStop = false;
            // 
            // textACPICommand
            // 
            textACPICommand.Location = new Point(467, 18);
            textACPICommand.Margin = new Padding(5, 3, 5, 3);
            textACPICommand.Name = "textACPICommand";
            textACPICommand.PlaceholderText = "Address";
            textACPICommand.Size = new Size(242, 39);
            textACPICommand.TabIndex = 21;
            textACPICommand.TabStop = false;
            // 
            // buttonACPISend
            // 
            buttonACPISend.Activated = false;
            buttonACPISend.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            buttonACPISend.BackColor = SystemColors.ButtonHighlight;
            buttonACPISend.BorderColor = Color.Transparent;
            buttonACPISend.BorderRadius = 2;
            buttonACPISend.FlatStyle = FlatStyle.Flat;
            buttonACPISend.Location = new Point(855, 13);
            buttonACPISend.Margin = new Padding(5, 3, 5, 3);
            buttonACPISend.Name = "buttonACPISend";
            buttonACPISend.Secondary = false;
            buttonACPISend.Size = new Size(106, 46);
            buttonACPISend.TabIndex = 20;
            buttonACPISend.Text = "Send";
            buttonACPISend.UseVisualStyleBackColor = false;
            // 
            // pictureDebug
            // 
            pictureDebug.BackgroundImage = Resources.icons8_heartbeat_32;
            pictureDebug.BackgroundImageLayout = ImageLayout.Zoom;
            pictureDebug.Location = new Point(21, 21);
            pictureDebug.Name = "pictureDebug";
            pictureDebug.Size = new Size(32, 32);
            pictureDebug.TabIndex = 1;
            pictureDebug.TabStop = false;
            // 
            // labelACPITitle
            // 
            labelACPITitle.AutoSize = true;
            labelACPITitle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            labelACPITitle.Location = new Point(57, 21);
            labelACPITitle.Name = "labelACPITitle";
            labelACPITitle.Size = new Size(188, 32);
            labelACPITitle.TabIndex = 0;
            labelACPITitle.Text = "ACPI DEVS Test";
            // 
            // panelOptimalBrightness
            // 
            panelOptimalBrightness.AutoSize = true;
            panelOptimalBrightness.Controls.Add(comboOptimalBrightness);
            panelOptimalBrightness.Controls.Add(pictureOptimalBrightness);
            panelOptimalBrightness.Controls.Add(labelOptimalBrightness);
            panelOptimalBrightness.Dock = DockStyle.Top;
            panelOptimalBrightness.Location = new Point(15, 1192);
            panelOptimalBrightness.Name = "panelOptimalBrightness";
            panelOptimalBrightness.Padding = new Padding(11, 5, 11, 0);
            panelOptimalBrightness.Size = new Size(949, 60);
            panelOptimalBrightness.TabIndex = 49;
            panelOptimalBrightness.Visible = false;
            // 
            // comboOptimalBrightness
            // 
            comboOptimalBrightness.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            comboOptimalBrightness.BorderColor = Color.White;
            comboOptimalBrightness.ButtonColor = SystemColors.ControlLight;
            comboOptimalBrightness.FlatStyle = FlatStyle.Flat;
            comboOptimalBrightness.Font = new Font("Segoe UI", 9F);
            comboOptimalBrightness.FormattingEnabled = true;
            comboOptimalBrightness.Items.AddRange(new object[] { "Off", "On Always", "On Battery" });
            comboOptimalBrightness.Location = new Point(618, 11);
            comboOptimalBrightness.Margin = new Padding(5, 11, 5, 9);
            comboOptimalBrightness.Name = "comboOptimalBrightness";
            comboOptimalBrightness.Size = new Size(309, 40);
            comboOptimalBrightness.TabIndex = 12;
            comboOptimalBrightness.TabStop = false;
            // 
            // pictureOptimalBrightness
            // 
            pictureOptimalBrightness.BackgroundImage = Resources.icons8_brightness_32;
            pictureOptimalBrightness.BackgroundImageLayout = ImageLayout.Zoom;
            pictureOptimalBrightness.Location = new Point(21, 11);
            pictureOptimalBrightness.Name = "pictureOptimalBrightness";
            pictureOptimalBrightness.Size = new Size(32, 32);
            pictureOptimalBrightness.TabIndex = 1;
            pictureOptimalBrightness.TabStop = false;
            // 
            // labelOptimalBrightness
            // 
            labelOptimalBrightness.AutoSize = true;
            labelOptimalBrightness.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            labelOptimalBrightness.Location = new Point(64, 10);
            labelOptimalBrightness.Name = "labelOptimalBrightness";
            labelOptimalBrightness.Size = new Size(323, 32);
            labelOptimalBrightness.TabIndex = 0;
            labelOptimalBrightness.Text = "Optimal Display Brightness";
            // 
            // Extra
            // 
            AutoScaleDimensions = new SizeF(192F, 192F);
            AutoScaleMode = AutoScaleMode.Dpi;
            AutoScroll = true;
            AutoSize = true;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            ClientSize = new Size(1013, 1759);
            Controls.Add(panelServices);
            Controls.Add(panelPower);
            Controls.Add(panelSettings);
            Controls.Add(panelOptimalBrightness);
            Controls.Add(panelAPU);
            Controls.Add(panelCores);
            Controls.Add(panelACPI);
            Controls.Add(panelSettingsHeader);
            Controls.Add(panelBacklight);
            Controls.Add(panelBacklightHeader);
            Controls.Add(panelBindings);
            Controls.Add(panelBindingsHeader);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(5, 3, 5, 3);
            MaximizeBox = false;
            MdiChildrenMinimizedAnchorBottom = false;
            MinimizeBox = false;
            MinimumSize = new Size(1033, 71);
            Name = "Extra";
            Padding = new Padding(15);
            ShowIcon = false;
            ShowInTaskbar = false;
            Text = "Extra Settings";
            panelServices.ResumeLayout(false);
            panelServices.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureService).EndInit();
            panelBindingsHeader.ResumeLayout(false);
            panelBindingsHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBindings).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureHelp).EndInit();
            panelBindings.ResumeLayout(false);
            panelBindings.PerformLayout();
            tableBindings.ResumeLayout(false);
            tableBindings.PerformLayout();
            panelBacklightHeader.ResumeLayout(false);
            panelBacklightHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBacklight).EndInit();
            panelBacklight.ResumeLayout(false);
            panelBacklight.PerformLayout();
            panelBacklightExtra.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)numericBacklightPluggedTime).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericBacklightTime).EndInit();
            panelXGM.ResumeLayout(false);
            panelXGM.PerformLayout();
            tableBacklight.ResumeLayout(false);
            panelSettingsHeader.ResumeLayout(false);
            panelSettingsHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureScan).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureLog).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureSettings).EndInit();
            panelSettings.ResumeLayout(false);
            panelSettings.PerformLayout();
            panelPower.ResumeLayout(false);
            panelPower.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericHibernateAfter).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureHibernate).EndInit();
            panelAPU.ResumeLayout(false);
            panelAPU.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureAPUMem).EndInit();
            panelCores.ResumeLayout(false);
            panelCores.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureCores).EndInit();
            panelACPI.ResumeLayout(false);
            panelACPI.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureDebug).EndInit();
            panelOptimalBrightness.ResumeLayout(false);
            panelOptimalBrightness.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureOptimalBrightness).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Panel panelServices;
        private RButton buttonServices;
        private Label labelServices;
        private Panel panelBindingsHeader;
        private RButton buttonResetBindings;
        private Panel panelBindings;
        private TableLayoutPanel tableBindings;
        private Label labelFNC;
        private Label labelFNV;
        private RTextBox textM2;
        private RTextBox textM1;
        private RComboBox comboM1;
        private Label labelM1;
        private RComboBox comboM4;
        private RComboBox comboM3;
        private RTextBox textM4;
        private RTextBox textM3;
        private Label labelM4;
        private Label labelM3;
        private RComboBox comboM5;
        private RTextBox textM5;
        private Label labelM5;
        private Label labelM2;
        private RComboBox comboM2;
        private Label labelFNF4;
        private RComboBox comboFNF4;
        private RTextBox textFNF4;
        private RComboBox comboFNC;
        private RComboBox comboFNV;
        private RTextBox textFNC;
        private RTextBox textFNV;
        private PictureBox pictureHelp;
        private TableLayoutPanel tableKeys;
        private PictureBox pictureBindings;
        private Label labelBindings;
        private Panel panelBacklightHeader;
        private Panel panelBacklight;
        private Panel panelBacklightExtra;
        private NumericUpDownWithUnit numericBacklightPluggedTime;
        private NumericUpDownWithUnit numericBacklightTime;
        private Label labelBacklightTimeout;
        private Label labelSpeed;
        private RComboBox comboKeyboardSpeed;
        private Panel panelXGM;
        private CheckBox checkXGM;
        private TableLayoutPanel tableBacklight;
        private Label labelBacklightKeyboard;
        private CheckBox checkAwake;
        private CheckBox checkBoot;
        private CheckBox checkSleep;
        private Label labelBacklightLogo;
        private CheckBox checkAwakeLogo;
        private CheckBox checkBootLogo;
        private CheckBox checkSleepLogo;
        private Label labelBacklightBar;
        private CheckBox checkAwakeBar;
        private CheckBox checkBootBar;
        private CheckBox checkSleepBar;
        private Label labelBacklightLid;
        private CheckBox checkAwakeLid;
        private CheckBox checkBootLid;
        private CheckBox checkSleepLid;
        private Panel panelSettingsHeader;
        private PictureBox pictureSettings;
        private Label labelSettings;
        private Panel panelSettings;
        private CheckBox checkTopmost;
        private CheckBox checkNoOverdrive;
        private CheckBox checkELMB;
        private CheckBox checkUSBC;
        private CheckBox checkGpuApps;
        private PictureBox pictureBacklight;
        private Label labelBacklightTitle;
        private PictureBox pictureService;
        private Slider sliderBrightness;
        private PictureBox pictureLog;
        private CheckBox checkAutoToggleClamshellMode;
        private Label labelFNE;
        private RComboBox comboFNE;
        private RTextBox textFNE;
        private Panel panelPower;
        private PictureBox pictureHibernate;
        private Label labelHibernateAfter;
        private NumericUpDownWithUnit numericHibernateAfter;
        private ToolTip toolTip;
        private CheckBox checkBootSound;
        private CheckBox checkKeystoneSound;
        private Panel panelAPU;
        private PictureBox pictureAPUMem;
        private Label labelAPUMem;
        private RComboBox comboAPU;
        private PictureBox pictureScan;
        private Panel panelCores;
        private RComboBox comboCoresE;
        private PictureBox pictureCores;
        private Label labelCores;
        private RComboBox comboCoresP;
        private RButton buttonCores;
        private Panel panelACPI;
        private RTextBox textACPIParam;
        private RTextBox textACPICommand;
        private RButton buttonACPISend;
        private PictureBox pictureDebug;
        private Label labelACPITitle;
        private CheckBox checkStatusLed;
        private CheckBox checkNumberPad;
        private CheckBox checkAspm;
        private CheckBox checkStandbyNetworking;
        private CheckBox checkBatteryLogo;
        private CheckBox checkBattery;
        private CheckBox checkBatteryLid;
        private CheckBox checkBatteryBar;
        private CheckBox checkNVPlatform;
        private Panel panelOptimalBrightness;
        private RComboBox comboOptimalBrightness;
        private PictureBox pictureOptimalBrightness;
        private Label labelOptimalBrightness;
    }
}