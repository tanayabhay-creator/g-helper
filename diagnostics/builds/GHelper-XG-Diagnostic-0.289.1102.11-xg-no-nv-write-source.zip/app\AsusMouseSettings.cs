﻿using GHelper.Peripherals;
using GHelper.Peripherals.Mouse;
using GHelper.UI;

namespace GHelper
{
    public partial class AsusMouseSettings : RForm
    {
        private static Dictionary<LightingMode, string> lightingModeNames = new Dictionary<LightingMode, string>()
        {
            { LightingMode.Static,Properties.Strings.AuraStatic},
            { LightingMode.Breathing, Properties.Strings.AuraBreathe},
            { LightingMode.ColorCycle, Properties.Strings.AuraColorCycle},
            { LightingMode.Rainbow, Properties.Strings.AuraRainbow},
            { LightingMode.React, Properties.Strings.AuraReact},
            { LightingMode.Comet, Properties.Strings.AuraComet},
            { LightingMode.BatteryState, Properties.Strings.AuraBatteryState},
            { LightingMode.Off, Properties.Strings.MatrixOff},
        };
        private List<LightingMode> supportedLightingModes = new List<LightingMode>();

        private readonly AsusMouse mouse;
        private readonly RButton[] dpiButtons;
        private LightingZone visibleZone = LightingZone.All;

        private bool updateMouseDPI = true;
        private bool loadingSettings = true;

        public AsusMouseSettings(AsusMouse mouse)
        {
            this.mouse = mouse;
            InitializeComponent();

            dpiButtons = new RButton[] { buttonDPI1, buttonDPI2, buttonDPI3, buttonDPI4 };


            labelPollingRate.Text = Properties.Strings.PollingRate;
            labelLighting.Text = Properties.Strings.Lighting;
            labelLightingMode.Text = Properties.Strings.AuraLightingMode;
            labelEnergy.Text = Properties.Strings.EnergySettings;
            labelPerformance.Text = Properties.Strings.MousePerformance;
            checkBoxRandomColor.Text = Properties.Strings.AuraRandomColor;
            checkBoxSyncAura.Text = Properties.Strings.MouseSyncWithAura;
            labelLowBatteryWarning.Text = Properties.Strings.MouseLowBatteryWarning;
            labelAutoPowerOff.Text = Properties.Strings.MouseAutoPowerOff;
            buttonSync.Text = Properties.Strings.MouseSynchronize;
            checkBoxAngleSnapping.Text = Properties.Strings.MouseAngleSnapping;
            labelLiftOffDistance.Text = Properties.Strings.MouseLiftOffDistance;
            labelChargingState.Text = "(" + Properties.Strings.Charging + ")";
            labelProfile.Text = Properties.Strings.Profile;
            labelButtonDebounce.Text = Properties.Strings.MouseButtonResponse;
            labelAcceleration.Text = Properties.Strings.Acceleration;
            labelDeceleration.Text = Properties.Strings.Deceleration;
            checkBoxMotionSync.Text = Properties.Strings.MouseMotionSync;
            checkBoxZoneMode.Text = Properties.Strings.MouseZoneMode;

            buttonLightingZoneLogo.Text = Properties.Strings.AuraZoneLogo;
            buttonLightingZoneScroll.Text = Properties.Strings.AuraZoneScroll;
            buttonLightingZoneUnderglow.Text = Properties.Strings.AuraZoneUnderglow;
            buttonLightingZoneAll.Text = Properties.Strings.AuraZoneAll;
            buttonLightingZoneDock.Text = Properties.Strings.AuraZoneDock;

            buttonExport.Text = Properties.Strings.Export;
            buttonImport.Text = Properties.Strings.Import;

            labelAnimationSpeed.Text = Properties.Strings.AnimationSpeed;
            labelAnimationDirection.Text = Properties.Strings.AnimationDirection;
            labelBindingsTitle.Text = Properties.Strings.KeyBindings;

            InitTheme(true);

            this.Text = mouse.GetDisplayName();

            Shown += AsusMouseSettings_Shown;
            FormClosing += AsusMouseSettings_FormClosing;

            comboProfile.DropDownClosed += ComboProfile_DropDownClosed;

            sliderDPI.ValueChanged += SliderDPI_ValueChanged;
            numericUpDownCurrentDPI.ValueChanged += NumericUpDownCurrentDPI_ValueChanged;
            sliderDPI.MouseUp += SliderDPI_MouseUp;
            sliderDPI.MouseDown += SliderDPI_MouseDown;
            sliderDPI.PreviewKeyDown += (_, _) => updateMouseDPI = false;
            sliderDPI.KeyUp += (s, e) => SliderDPI_MouseUp(s, e);
            buttonDPIColor.Click += ButtonDPIColor_Click;
            buttonDPI1.Click += ButtonDPI_Click;
            buttonDPI2.Click += ButtonDPI_Click;
            buttonDPI3.Click += ButtonDPI_Click;
            buttonDPI4.Click += ButtonDPI_Click;

            // Subscribe to Paint and MouseMove for Delete logic
            foreach (var btn in dpiButtons)
            {
                btn.Paint += DpiButton_Paint;
                btn.MouseMove += DpiButton_MouseMove;
                btn.MouseLeave += (s, e) => { (s as Control)?.Invalidate(); }; 
            }

            comboBoxPollingRate.DropDownClosed += ComboBoxPollingRate_DropDownClosed;
            checkBoxAngleSnapping.CheckedChanged += CheckAngleSnapping_CheckedChanged;
            sliderAngleAdjustment.ValueChanged += SliderAngleAdjustment_ValueChanged;
            sliderAngleAdjustment.MouseUp += SliderAngleAdjustment_MouseUp;
            sliderAngleAdjustment.KeyUp += SliderAngleAdjustment_MouseUp;
            comboBoxLiftOffDistance.DropDownClosed += ComboBoxLiftOffDistance_DropDownClosed;
            sliderButtonDebounce.ValueChanged += SliderButtonDebounce_ValueChanged;
            sliderButtonDebounce.MouseUp += SliderButtonDebounce_MouseUp;
            sliderButtonDebounce.KeyUp += SliderButtonDebounce_MouseUp;

            checkBoxMotionSync.CheckedChanged += CheckBoxMotionSync_CheckedChanged;
            checkBoxZoneMode.CheckedChanged += CheckBoxZoneMode_CheckedChanged;
            sliderZoneModeDPI.ValueChanged += SliderZoneModeDPI_ValueChanged;
            sliderZoneModeDPI.MouseUp += SliderZoneModeDPI_MouseUp;
            sliderZoneModeDPI.KeyUp += SliderZoneModeDPI_MouseUp;
            numericUpDownZoneModeDPI.ValueChanged += NumericUpDownZoneModeDPI_ValueChanged;
            comboBoxZoneModePollingRate.DropDownClosed += ComboBoxZoneModePollingRate_DropDownClosed;

            sliderAcceleration.MouseUp += SliderAcceleration_MouseUp;
            sliderAcceleration.KeyUp += SliderAcceleration_MouseUp;
            sliderAcceleration.ValueChanged += SliderAcceleration_ValueChanged;

            sliderDeceleration.MouseUp += SliderDeceleration_MouseUp;
            sliderDeceleration.KeyUp += SliderDeceleration_MouseUp;
            sliderDeceleration.ValueChanged += SliderDeceleration_ValueChanged;

            buttonLightingColor.Click += ButtonLightingColor_Click;
            comboBoxLightingMode.DropDownClosed += ComboBoxLightingMode_DropDownClosed;
            sliderBrightness.MouseUp += SliderBrightness_MouseUp;
            sliderBrightness.KeyUp += SliderBrightness_MouseUp;
            comboBoxAnimationSpeed.DropDownClosed += ComboBoxAnimationSpeed_DropDownClosed;
            comboBoxAnimationDirection.DropDownClosed += ComboBoxAnimationDirection_DropDownClosed;
            checkBoxRandomColor.CheckedChanged += CheckBoxRandomColor_CheckedChanged;
            checkBoxSyncAura.CheckedChanged += CheckBoxSyncAura_CheckedChanged;

            sliderLowBatteryWarning.ValueChanged += SliderLowBatteryWarning_ValueChanged;
            sliderLowBatteryWarning.MouseUp += SliderLowBatteryWarning_MouseUp;
            sliderLowBatteryWarning.KeyUp += SliderLowBatteryWarning_MouseUp;
            comboBoxAutoPowerOff.DropDownClosed += ComboBoxAutoPowerOff_DropDownClosed;


            buttonLightingZoneAll.Click += ButtonLightingZoneAll_Click;
            buttonLightingZoneDock.Click += ButtonLightingZoneDock_Click;
            buttonLightingZoneLogo.Click += ButtonLightingZoneLogo_Click;
            buttonLightingZoneUnderglow.Click += ButtonLightingZoneUnderglow_Click;
            buttonLightingZoneScroll.Click += ButtonLightingZoneScroll_Click;

            InitMouseCapabilities();
            Logger.WriteLine(mouse.GetDisplayName() + " (GUI): Initialized capabilities. Synchronizing mouse data");
            RefreshMouseData();

            loadingSettings = false;
        }

        public void ToggleBindingsPanel(bool show)
        {
            if (!mouse.HasButtonBindings()) show = false;
            tableRoot.ColumnStyles[0] = show
                ? new ColumnStyle(SizeType.AutoSize)
                : new ColumnStyle(SizeType.Absolute, 0);
            panelLeft.Visible = show;
        }

        private void SliderAcceleration_MouseUp(object? sender, EventArgs e)
        {
            mouse.SetAcceleration(sliderAcceleration.Value);
        }

        private void SliderAcceleration_ValueChanged(object? sender, EventArgs e)
        {
            labelAccelerationValue.Text = sliderAcceleration.Value.ToString();
        }

        private void SliderDeceleration_MouseUp(object? sender, EventArgs e)
        {
            mouse.SetDeceleration(sliderDeceleration.Value);
        }

        private void SliderDeceleration_ValueChanged(object? sender, EventArgs e)
        {
            labelDecelerationValue.Text = sliderDeceleration.Value.ToString();
        }

        private void SliderButtonDebounce_MouseUp(object? sender, EventArgs e)
        {
            DebounceTime dbt = (DebounceTime)sliderButtonDebounce.Value;
            mouse.SetDebounce(dbt);
        }

        private void SliderButtonDebounce_ValueChanged(object? sender, EventArgs e)
        {
            DebounceTime dbt = (DebounceTime)sliderButtonDebounce.Value;
            int time = mouse.DebounceTimeInMS(dbt);

            labelButtonDebounceValue.Text = time + "ms";
        }

        private void SwitchLightingZone(LightingZone zone)
        {
            if (!mouse.HasRGB())
            {
                return;
            }
            visibleZone = zone;
            InitLightingModes();
            VisusalizeLightingSettings();
        }

        private void ButtonLightingZoneScroll_Click(object? sender, EventArgs e)
        {
            SwitchLightingZone(LightingZone.Scrollwheel);
        }

        private void ButtonLightingZoneUnderglow_Click(object? sender, EventArgs e)
        {
            SwitchLightingZone(LightingZone.Underglow);
        }

        private void ButtonLightingZoneLogo_Click(object? sender, EventArgs e)
        {
            SwitchLightingZone(LightingZone.Logo);
        }

        private void ButtonLightingZoneDock_Click(object? sender, EventArgs e)
        {
            SwitchLightingZone(LightingZone.Dock);
        }

        private void ButtonLightingZoneAll_Click(object? sender, EventArgs e)
        {
            SwitchLightingZone(LightingZone.All);
        }

        private void AsusMouseSettings_FormClosing(object? sender, FormClosingEventArgs e)
        {
            mouse.StopEventListener();
            mouse.ProfileChanged -= Mouse_ProfileChanged;
            mouse.BatteryUpdated -= Mouse_BatteryUpdated;
            mouse.Disconnect -= Mouse_Disconnect;
            mouse.MouseReadyChanged -= Mouse_MouseReadyChanged;
        }

        private void Mouse_MouseReadyChanged(object? sender, EventArgs e)
        {
            if (Disposing || IsDisposed)
            {
                return;
            }
            if (!mouse.IsDeviceReady)
            {
                this.Invoke(delegate
                {
                    Close();
                });
            }
        }

        private void Mouse_ProfileChanged(object? sender, EventArgs e)
        {
            if (Disposing || IsDisposed) return;
            try { BeginInvoke(VisualizeMouseSettings); } catch { }
        }

        private void Mouse_BatteryUpdated(object? sender, EventArgs e)
        {
            if (Disposing || IsDisposed)
            {
                return;
            }
            this.Invoke(delegate
            {
                VisualizeBatteryState();
            });

        }

        private void ComboProfile_DropDownClosed(object? sender, EventArgs e)
        {
            if (mouse.Profile == comboProfile.SelectedIndex)
            {
                return;
            }

            mouse.SetProfile(comboProfile.SelectedIndex);
            RefreshMouseData();
        }

        private void ComboBoxPollingRate_DropDownClosed(object? sender, EventArgs e)
        {
            mouse.SetPollingRate(mouse.SupportedPollingrates()[comboBoxPollingRate.SelectedIndex]);
            UpdateMotionSyncState();
        }

        private void ButtonDPIColor_Click(object? sender, EventArgs e)
        {
            AsusMouseDPI dpi = mouse.DpiSettings[mouse.DpiProfile - 1];

            RColorPicker colorDlg = new RColorPicker(dpi.Color);
            colorDlg.ColorChanged += c =>
            {
                dpi.Color = c;
                mouse.SetDPIForProfile(dpi, mouse.DpiProfile);

                VisualizeDPIButtons();
                VisualizeCurrentDPIProfile();
            };
            colorDlg.ShowDialog(this);
        }

        // Logic for Delete Area
        bool IsOverDeleteArea(Control btn, Point p)
        {
             // Top Right corner
             float size = 16 * ControlHelper.Scale;
             if (p.X > btn.Width - size - 5 && p.Y < size + 5) return true;
             return false;
        }

        private void DpiButton_MouseMove(object? sender, MouseEventArgs e)
        {
            if (sender is RButton btn)
            {
                // Trigger repaint to show/hide X
                btn.Invalidate();
            }
        }

        private void DpiButton_Paint(object? sender, PaintEventArgs e)
        {
            if (sender is not RButton btn) return;
            
            int index = Array.IndexOf(dpiButtons, btn);
            if (index == -1 || index >= mouse.CurrentDPIProfileCount) return;
            if (!mouse.CanChangeDPICount()) return;
            if (mouse.CurrentDPIProfileCount <= 2) return;

            // Check if mouse is within client area to draw hover effect
            Point clientPoint = btn.PointToClient(Cursor.Position);
            if (!btn.ClientRectangle.Contains(clientPoint)) return;

            // Draw X in top right (gray-white color)
            Image img = ControlHelper.ResizeImage(
                ControlHelper.TintImage(Properties.Resources.cross_23, Color.FromArgb(170, 170, 170)),
                ControlHelper.Scale);
            e.Graphics.DrawImage(img, new Point(btn.Width - img.Width - 5, 5));
        }

        private void ButtonDPI_Click(object? sender, EventArgs e)
        {
            int index = -1;

            for (int i = 0; i < dpiButtons.Length; ++i)
            {
                if (sender == dpiButtons[i])
                {
                    index = i;
                    break;
                }
            }

            if (index == -1) return;
            
            // Check for Delete Click
            if (mouse.CanChangeDPICount() && index < mouse.CurrentDPIProfileCount && mouse.CurrentDPIProfileCount > 2)
            {
                Point p = dpiButtons[index].PointToClient(Cursor.Position);
                if (IsOverDeleteArea(dpiButtons[index], p))
                {
                    mouse.DeleteDPIProfile(index);
                    VisualizeDPIButtons();
                    VisualizeCurrentDPIProfile();
                    return;
                }
            }

            // Logic:
            // If index < CurrentCount -> Switch Profile
            // If index == CurrentCount -> Add Profile

            if (index < mouse.CurrentDPIProfileCount)
            {
                mouse.SetDPIProfile(index + 1);
            }
            else if (index == mouse.CurrentDPIProfileCount)
            {
                mouse.AddDPIProfile();
                // Ensure UI re-renders to show new profile
                VisualizeDPIButtons();
                VisualizeCurrentDPIProfile();
                return;
            }

            VisualizeDPIButtons();
            VisualizeCurrentDPIProfile();
        }

        private void UpdateLightingSettings(LightingSetting settings, LightingZone zone)
        {
            mouse.SetLightingSetting(settings, visibleZone);
            VisusalizeLightingSettings();
        }

        private void CheckBoxRandomColor_CheckedChanged(object? sender, EventArgs e)
        {
            LightingSetting? ls = mouse.LightingSettingForZone(visibleZone);
            ls.RandomColor = checkBoxRandomColor.Checked;

            UpdateLightingSettings(ls, visibleZone);
        }

        private void CheckBoxSyncAura_CheckedChanged(object? sender, EventArgs e)
        {
            ApplyAuraSyncUIState();
            if (loadingSettings) return;

            PeripheralsProvider.SetAuraSync(checkBoxSyncAura.Checked);
            Program.settingsForm.UpdateKeyboardLabel();

            if (checkBoxSyncAura.Checked)
            {
                mouse.SyncFromKeyboardAura();
                VisusalizeLightingSettings();
            }
        }

        private void ApplyAuraSyncUIState()
        {
            bool syncOn = checkBoxSyncAura.Checked;
            comboBoxLightingMode.Enabled = !syncOn;
            buttonLightingColor.Enabled = !syncOn;
            checkBoxRandomColor.Enabled = !syncOn;
            comboBoxAnimationSpeed.Enabled = !syncOn;
            comboBoxAnimationDirection.Enabled = !syncOn;
        }

        private void ComboBoxAnimationDirection_DropDownClosed(object? sender, EventArgs e)
        {
            LightingSetting? ls = mouse.LightingSettingForZone(visibleZone);
            ls.AnimationDirection = (AnimationDirection)comboBoxAnimationDirection.SelectedIndex;

            UpdateLightingSettings(ls, visibleZone);
        }

        private void ComboBoxAnimationSpeed_DropDownClosed(object? sender, EventArgs e)
        {
            LightingSetting? ls = mouse.LightingSettingForZone(visibleZone);
            // 0 => 0x9
            // 1 => 0x7
            // 2 => 0x5
            ls.AnimationSpeed = (AnimationSpeed)(0x9 - (comboBoxAnimationSpeed.SelectedIndex * 0x2));
            UpdateLightingSettings(ls, visibleZone);
        }

        private void SliderBrightness_MouseUp(object? sender, EventArgs e)
        {
            LightingSetting? ls = mouse.LightingSettingForZone(visibleZone);
            ls.Brightness = sliderBrightness.Value;

            UpdateLightingSettings(ls, visibleZone);
        }

        private void ComboBoxLightingMode_DropDownClosed(object? sender, EventArgs e)
        {
            if (!mouse.HasRGB())
            {
                return;
            }

            var index = comboBoxLightingMode.SelectedIndex;
            LightingMode lm = supportedLightingModes[(index >= 0 && index < supportedLightingModes.Count) ? index : 0];

            LightingSetting? ls = mouse.LightingSettingForZone(visibleZone);
            if (ls.LightingMode == lm)
            {
                //Nothing to do here.
                return;
            }

            ls.LightingMode = lm;

            UpdateLightingSettings(ls, visibleZone);
        }

        private void ButtonLightingColor_Click(object? sender, EventArgs e)
        {
            LightingSetting? ls = mouse.LightingSettingForZone(visibleZone);
            if (ls is null) return;

            RColorPicker colorDlg = new RColorPicker(ls.RGBColor);
            colorDlg.ColorChanged += c =>
            {
                ls.RGBColor = c;
                UpdateLightingSettings(ls, visibleZone);
            };
            colorDlg.ShowDialog(this);
        }

        private void SliderLowBatteryWarning_ValueChanged(object? sender, EventArgs e)
        {
            labelLowBatteryWarningValue.Text = sliderLowBatteryWarning.Value.ToString() + "%";
        }

        private void SliderLowBatteryWarning_MouseUp(object? sender, EventArgs e)
        {
            mouse.SetEnergySettings(sliderLowBatteryWarning.Value, mouse.PowerOffSetting);
        }


        private void ComboBoxAutoPowerOff_DropDownClosed(object? sender, EventArgs e)
        {
            object? obj = Enum.GetValues(typeof(PowerOffSetting)).GetValue(comboBoxAutoPowerOff.SelectedIndex);
            if (obj is null)
            {
                return;
            }
            PowerOffSetting pos = (PowerOffSetting)obj;


            mouse.SetEnergySettings(mouse.LowBatteryWarning, pos);
        }

        private void SliderAngleAdjustment_ValueChanged(object? sender, EventArgs e)
        {
            labelAngleAdjustmentValue.Text = sliderAngleAdjustment.Value.ToString() + "°";
        }

        private void SliderAngleAdjustment_MouseUp(object? sender, EventArgs e)
        {
            mouse.SetAngleAdjustment((short)sliderAngleAdjustment.Value);
        }

        private void ComboBoxLiftOffDistance_DropDownClosed(object? sender, EventArgs e)
        {
            mouse.SetLiftOffDistance((LiftOffDistance)comboBoxLiftOffDistance.SelectedIndex);
        }

        private void CheckAngleSnapping_CheckedChanged(object? sender, EventArgs e)
        {
            mouse.SetAngleSnapping(checkBoxAngleSnapping.Checked);
            mouse.SetAngleAdjustment((short)sliderAngleAdjustment.Value);
        }

        private void CheckBoxMotionSync_CheckedChanged(object? sender, EventArgs e)
        {
            mouse.SetMotionSync(checkBoxMotionSync.Checked);
        }

        private void CheckBoxZoneMode_CheckedChanged(object? sender, EventArgs e)
        {
            mouse.SetZoneMode(checkBoxZoneMode.Checked);
            UpdateZoneModeUIState();
        }

        private void SliderZoneModeDPI_ValueChanged(object? sender, EventArgs e)
        {
            numericUpDownZoneModeDPI.Value = sliderZoneModeDPI.Value;
        }

        private void SliderZoneModeDPI_MouseUp(object? sender, EventArgs e)
        {
            mouse.ZoneModeDPI = sliderZoneModeDPI.Value;
            if (mouse.ZoneMode)
            {
                mouse.UpdateZoneModeDPI(sliderZoneModeDPI.Value);
            }
        }

        private void NumericUpDownZoneModeDPI_ValueChanged(object? sender, EventArgs e)
        {
            sliderZoneModeDPI.Value = (int)numericUpDownZoneModeDPI.Value;
            if (mouse.ZoneMode && mouse.ZoneModeDPI != sliderZoneModeDPI.Value)
            {
                mouse.ZoneModeDPI = sliderZoneModeDPI.Value;
                mouse.UpdateZoneModeDPI(sliderZoneModeDPI.Value);
            }
        }

        private void ComboBoxZoneModePollingRate_DropDownClosed(object? sender, EventArgs e)
        {
            PollingRate[] zoneModePollingRates = { PollingRate.PR1000Hz, PollingRate.PR2000Hz, PollingRate.PR4000Hz, PollingRate.PR8000Hz };
            if (comboBoxZoneModePollingRate.SelectedIndex >= 0 && comboBoxZoneModePollingRate.SelectedIndex < zoneModePollingRates.Length)
            {
                mouse.ZoneModePollingRate = zoneModePollingRates[comboBoxZoneModePollingRate.SelectedIndex];
                if (mouse.ZoneMode)
                {
                    mouse.UpdateZoneModePollingRate(mouse.ZoneModePollingRate);
                }
            }
        }

        private void SliderDPI_ValueChanged(object? sender, EventArgs e)
        {
            numericUpDownCurrentDPI.Value = sliderDPI.Value;
            UpdateMouseDPISettings();
        }

        private void NumericUpDownCurrentDPI_ValueChanged(object? sender, EventArgs e)
        {
            sliderDPI.Value = (int)numericUpDownCurrentDPI.Value;
        }

        private void SliderDPI_MouseDown(object? sender, MouseEventArgs e)
        {
            updateMouseDPI = false;
        }

        private void SliderDPI_MouseUp(object? sender, EventArgs e)
        {
            updateMouseDPI = true;
            UpdateMouseDPISettings();
        }

        private void UpdateMouseDPISettings()
        {
            if (!updateMouseDPI)
            {
                return;
            }
            AsusMouseDPI dpi = mouse.DpiSettings[mouse.DpiProfile - 1];
            dpi.DPI = (uint)sliderDPI.Value;

            mouse.SetDPIForProfile(dpi, mouse.DpiProfile);

            VisualizeDPIButtons();
            VisualizeCurrentDPIProfile();
        }

        private void Mouse_Disconnect(object? sender, EventArgs e)
        {
            if (Disposing || IsDisposed)
            {
                return;
            }
            //Mouse disconnected. Bye bye.
            this.Invoke(delegate
            {
                this.Close();
            });

        }

        private void RefreshMouseData()
        {
            mouse.SynchronizeDevice();

            Logger.WriteLine(mouse.GetDisplayName() + " (GUI): Mouse data synchronized");
            if (!mouse.IsDeviceReady)
            {
                Logger.WriteLine(mouse.GetDisplayName() + " (GUI): Mouse is not ready. Closing view.");
                Mouse_Disconnect(this, EventArgs.Empty);
                return;
            }

            if (Disposing || IsDisposed)
            {
                return;
            }

            VisualizeMouseSettings();
            VisualizeBatteryState();
            ToggleBindingsPanel(mouse.ButtonBindingsReady);
        }

        private void InitMouseCapabilities()
        {
            for (int i = 0; i < mouse.ProfileCount(); ++i)
            {
                String prf = Properties.Strings.Profile + " " + (i + 1);
                comboProfile.Items.Add(prf);
            }

            labelMinDPI.Text = mouse.MinDPI().ToString();
            labelMaxDPI.Text = mouse.MaxDPI().ToString();

            sliderDPI.Max = mouse.MaxDPI();
            sliderDPI.Min = mouse.MinDPI();
            sliderDPI.Step = mouse.DPIIncrements();
            sliderDPI.Exponential = true;

            numericUpDownCurrentDPI.Minimum = mouse.MinDPI();
            numericUpDownCurrentDPI.Maximum = mouse.MaxDPI();
            numericUpDownCurrentDPI.Increment = mouse.DPIIncrements();

            sliderZoneModeDPI.Max = mouse.MaxDPI();
            sliderZoneModeDPI.Step = mouse.DPIIncrements();
            numericUpDownZoneModeDPI.Maximum = mouse.MaxDPI();
            numericUpDownZoneModeDPI.Increment = mouse.DPIIncrements();

            if (!mouse.HasDebounceSetting())
            {
                panelDebounce.Visible = false;
            }


            if (!mouse.HasDPIColors())
            {
                buttonDPIColor.Visible = false;
                buttonDPI1.Image = ControlHelper.ResizeImage(ControlHelper.TintImage(Properties.Resources.lighting_dot_32, Color.Red), ControlHelper.Scale);
                buttonDPI2.Image = ControlHelper.ResizeImage(ControlHelper.TintImage(Properties.Resources.lighting_dot_32, Color.Purple), ControlHelper.Scale);
                buttonDPI3.Image = ControlHelper.ResizeImage(ControlHelper.TintImage(Properties.Resources.lighting_dot_32, Color.Blue), ControlHelper.Scale);
                buttonDPI4.Image = ControlHelper.ResizeImage(ControlHelper.TintImage(Properties.Resources.lighting_dot_32, Color.Green), ControlHelper.Scale);

                buttonDPI1.BorderColor = Color.Red;
                buttonDPI2.BorderColor = Color.Purple;
                buttonDPI3.BorderColor = Color.Blue;
                buttonDPI4.BorderColor = Color.Green;
            }

            if (mouse.CanSetPollingRate())
            {
                foreach (PollingRate pr in mouse.SupportedPollingrates())
                {
                    comboBoxPollingRate.Items.Add(mouse.PollingRateDisplayString(pr));
                }

            }
            else
            {
                panelPollingRate.Visible = false;
            }

            if (!mouse.HasAngleSnapping())
            {
                checkBoxAngleSnapping.Visible = false;
            }

            if (!mouse.HasAngleTuning())
            {
                labelAngleAdjustmentValue.Visible = false;
                sliderAngleAdjustment.Visible = false;
                sliderAngleAdjustment.Max = mouse.AngleTuningMax();
                sliderAngleAdjustment.Min = mouse.AngleTuningMin();
                sliderAngleAdjustment.Step = mouse.AngleTuningStep();
            }

            if (!mouse.HasAngleTuning() && !mouse.HasAngleSnapping())
            {
                panelAngleSnapping.Visible = false;
            }

            if (!mouse.HasMotionSync())
            {
                panelMotionSync.Visible = false;
            }

            if (!mouse.HasZoneMode())
            {
                panelZoneMode.Visible = false;
            }
            else
            {
                // Initialize Zone Mode Polling Rate combobox with limited options
                comboBoxZoneModePollingRate.Items.Clear();
                comboBoxZoneModePollingRate.Items.Add("1000 Hz");
                comboBoxZoneModePollingRate.Items.Add("2000 Hz");
                comboBoxZoneModePollingRate.Items.Add("4000 Hz");
                comboBoxZoneModePollingRate.Items.Add("8000 Hz");
                comboBoxZoneModePollingRate.SelectedIndex = 2; // Default to 4000Hz
            }

            if (mouse.HasAcceleration())
            {
                sliderAcceleration.Max = mouse.MaxAcceleration();
            }
            else
            {
                panelAcceleration.Visible = false;
            }

            if (mouse.HasDeceleration())
            {
                sliderDeceleration.Max = mouse.MaxDeceleration();
            }
            else
            {
                panelDeceleration.Visible = false;
            }

            if (mouse.HasLiftOffSetting())
            {
                comboBoxLiftOffDistance.Items.AddRange(new string[] {
                    Properties.Strings.Low,
                    Properties.Strings.High,
                });
            }
            else
            {
                panelLiftOffDistance.Visible = false;
            }

            if (mouse.DPIProfileCount() < 4)
            {
                for (int i = 3; i > mouse.DPIProfileCount() - 1; --i)
                {
                    dpiButtons[i].Visible = false;
                }
            }

            if (mouse.DPIProfileCount() == 0)
            {
                panelPerformance.Visible = false;
            }

            if (!mouse.HasBattery())
            {
                panelBatteryState.Visible = false;
            }

            if (!mouse.HasProfiles())
            {
                panelProfiles.Visible = false;
                panelBottomButtons.Visible = false;
            }

            if (mouse.HasAutoPowerOff())
            {
                comboBoxAutoPowerOff.Items.AddRange(new string[]{
                    " 1 "+ Properties.Strings.Minute,
                    " 2 "+ Properties.Strings.Minutes,
                    " 3 "+ Properties.Strings.Minutes,
                    " 5 "+ Properties.Strings.Minutes,
                    "10 "+ Properties.Strings.Minutes,
                     Properties.Strings.Never,
                });
            }

            if (!mouse.HasLowBatteryWarning())
            {
                labelLowBatteryWarning.Visible = false;
                labelLowBatteryWarningValue.Visible = false;
                sliderLowBatteryWarning.Visible = false;
            }
            else
            {
                sliderLowBatteryWarning.Min = 0;
                sliderLowBatteryWarning.Step = mouse.LowBatteryWarningStep();
                sliderLowBatteryWarning.Max = mouse.LowBatteryWarningMax();
            }

            if (!mouse.HasAutoPowerOff() && !mouse.HasLowBatteryWarning())
            {
                panelEnergy.Visible = false;
            }

            if (mouse.HasRGB())
            {
                if (mouse.SupportedLightingZones().Length > 1)
                {
                    buttonLightingZoneLogo.Visible = mouse.SupportedLightingZones().Contains(LightingZone.Logo);
                    buttonLightingZoneScroll.Visible = mouse.SupportedLightingZones().Contains(LightingZone.Scrollwheel);
                    buttonLightingZoneUnderglow.Visible = mouse.SupportedLightingZones().Contains(LightingZone.Underglow);
                    buttonLightingZoneDock.Visible = mouse.SupportedLightingZones().Contains(LightingZone.Dock);
                }
                else
                {
                    buttonLightingZoneLogo.Visible = false;
                    buttonLightingZoneScroll.Visible = false;
                    buttonLightingZoneUnderglow.Visible = false;
                    buttonLightingZoneDock.Visible = false;
                }

                checkBoxSyncAura.Checked = AppConfig.IsAuraSync();
                ApplyAuraSyncUIState();

                sliderBrightness.Max = mouse.MaxBrightness();

                InitLightingModes();

                comboBoxAnimationDirection.Items.AddRange(new string[] {
                    Properties.Strings.AuraClockwise,
                    Properties.Strings.AuraCounterClockwise,
                });

                comboBoxAnimationSpeed.Items.AddRange(new string[] {
                    Properties.Strings.AuraSlow,
                    Properties.Strings.AuraNormal,
                    Properties.Strings.AuraFast
                });
            }
            else
            {
                panelLighting.Visible = false;
            }

            if (mouse.HasButtonBindings())
            {
                InitBindingCombos();
                ControlHelper.Adjust(this);
            }
        }

        private bool _updatingBindings;
        private bool _shiftLayer;
        private readonly List<UI.RComboBox> _bindingCombos = new();
        private object[] _bindingComboItems = [];

        private object[] BuildBindingComboItems()
        {
            var list = new List<object>();
            foreach (var (groupLabel, items) in mouse.BindingGroups)
            {
                list.Add(new BindingSeparator(groupLabel));
                foreach (var (code, name) in items)
                    list.Add(new BindingItem(code, name));
            }
            return list.ToArray();
        }

        private void InitBindingCombos()
        {
            var slots = mouse.ButtonSlots;
            _bindingComboItems = BuildBindingComboItems();
            tableBindingsNav.Visible = mouse.HasSpeedShift;
            buttonBindingsNormal.BorderColor = RForm.colorStandard;
            buttonBindingsShift.BorderColor = RForm.colorStandard;

            float s = DeviceDpi / 192f;

            // Start below whichever is lower: the header or the mouse layout picture
            int startY = Math.Max(panelBindingsHeader.Bottom, pictureMouseLayout.Bottom) + (int)(12 * s);
            int rowHeight = (int)(52 * s);
            int row = 0;
            foreach (var (slot, (_, name)) in slots)
            {
                int y = startY + row * rowHeight;
                var lbl = new Label
                {
                    Text = name,
                    Location = new Point((int)(14 * s), y + (int)(14 * s)),
                    Size = new Size((int)(200 * s), (int)(32 * s)),
                    TextAlign = ContentAlignment.MiddleLeft,
                    ForeColor = RForm.foreMain,
                };
                var cmb = new UI.RComboBox
                {
                    Location = new Point((int)(220 * s), y + (int)(10 * s)),
                    Size = new Size((int)(260 * s), (int)(40 * s)),
                    Margin = new Padding(0, (int)(6 * s), (int)(6 * s), (int)(6 * s)),
                    DropDownStyle = ComboBoxStyle.DropDownList,
                    FlatStyle = FlatStyle.Flat,
                    UseCustomTextPadding = false,
                    DrawMode = DrawMode.OwnerDrawFixed,
                    ItemHeight = comboProfile.ItemHeight,
                    BackColor = RForm.buttonMain,
                    ForeColor = RForm.foreMain,
                    BorderColor = RForm.buttonMain,
                    ButtonColor = RForm.buttonMain,
                    ArrowColor = RForm.foreMain,
                };
                cmb.Items.AddRange(_bindingComboItems);
                cmb.Tag = slot;
                cmb.DrawItem += RComboBox.DrawBindingItem;
                cmb.SelectedIndexChanged += BindingCombo_Changed;
                panelLeft.Controls.Add(lbl);
                panelLeft.Controls.Add(cmb);
                _bindingCombos.Add(cmb);
                row++;
            }

            // Reset Bindings button below all rows
            int btnY = startY + row * rowHeight + (int)(8 * s);
            var btnReset = new UI.RButton
            {
                Text = Properties.Strings.Reset,
                Location = new Point((int)(14 * s), btnY),
                Size = new Size((int)(466 * s), (int)(50 * s)),
                FlatStyle = FlatStyle.Flat,
                Margin = new Padding((int)(4 * s), (int)(8 * s), (int)(4 * s), (int)(8 * s)),
                BackColor = SystemColors.ButtonHighlight,
                ForeColor = SystemColors.ControlText,
                BorderColor = Color.Transparent,
                BorderRadius = 2,
                Activated = false,
                Secondary = false,
                UseVisualStyleBackColor = false,
            };
            btnReset.Click += ButtonResetBindings_Click;
            panelLeft.Controls.Add(btnReset);
        }

        private void ButtonBindingsNormal_Click(object? sender, EventArgs e) => SetBindingLayer(false);

        private void ButtonBindingsShift_Click(object? sender, EventArgs e) => SetBindingLayer(true);

        private void SetBindingLayer(bool shift)
        {
            _shiftLayer = shift;
            buttonBindingsNormal.Activated = !shift;
            buttonBindingsNormal.Secondary = shift;
            buttonBindingsShift.Activated = shift;
            buttonBindingsShift.Secondary = !shift;
            VisualizeButtonBindings();
        }

        private void ButtonResetBindings_Click(object? sender, EventArgs e)
        {
            mouse.ResetButtonBindings();
            VisualizeButtonBindings();
            Program.inputDispatcher?.RegisterKeys();
        }

        private void BindingCombo_Changed(object? sender, EventArgs e)
        {
            if (_updatingBindings || sender is not UI.RComboBox cmb || cmb.Tag is not int slot) return;
            if (cmb.SelectedItem is BindingSeparator)
            {
                // Separator selected — step forward to first real item in group
                int next = cmb.SelectedIndex + 1;
                if (next < cmb.Items.Count && cmb.Items[next] is BindingItem)
                    cmb.SelectedIndex = next;
                return;
            }
            if (cmb.SelectedItem is BindingItem item)
            {
                if (_shiftLayer)
                {
                    if (item.Code == AsusMouse.SpeedShiftCode) VisualizeButtonBindings();
                    else mouse.SetSpeedShiftBinding(slot, item.Code);
                    return;
                }
                mouse.SetButtonBinding(slot, item.Code);
                Program.inputDispatcher?.RegisterKeys();
            }
        }

        private void VisualizeButtonBindings()
        {
            if (!mouse.HasButtonBindings()) return;
            var slots = mouse.ButtonSlots;
            _updatingBindings = true;
            int row = 0;
            foreach (var slot in slots.Keys)
            {
                if (row >= _bindingCombos.Count) break;
                var cmb = _bindingCombos[row];

                bool locked = _shiftLayer && mouse.ButtonBindings[slot] == AsusMouse.SpeedShiftCode;
                ushort code = _shiftLayer && !locked ? mouse.GetSpeedShiftBinding(slot) : mouse.ButtonBindings[slot];
                cmb.Enabled = !locked;

                for (int j = 0; j < cmb.Items.Count; j++)
                {
                    if (cmb.Items[j] is BindingItem item && item.Code == code)
                    { cmb.SelectedIndex = j; break; }
                }
                row++;
            }
            _updatingBindings = false;
        }

        private void InitLightingModes()
        {
            comboBoxLightingMode.Items.Clear();
            supportedLightingModes.Clear();
            foreach (LightingMode lm in Enum.GetValues(typeof(LightingMode)))
            {
                if (mouse.IsLightingModeSupported(lm) && mouse.IsLightingModeSupportedForZone(lm, visibleZone))
                {
                    comboBoxLightingMode.Items.Add(lightingModeNames.GetValueOrDefault(lm));
                    supportedLightingModes.Add(lm);
                }
            }
        }


        private void VisualizeMouseSettings()
        {
            if (mouse.Profile < comboProfile.Items.Count)
                comboProfile.SelectedIndex = mouse.Profile;

            if (mouse.HasRGB())
            {
                //If current lighting mode is zoned, pre-select the first zone and not "All".
                bool zoned = mouse.IsLightingZoned();
                if (zoned)
                {
                    visibleZone = mouse.SupportedLightingZones()[0];
                    InitLightingModes();
                }
            }


            VisualizeDPIButtons();
            VisualizeCurrentDPIProfile();
            VisusalizeLightingSettings();

            if (mouse.CanSetPollingRate())
            {
                int idx = mouse.PollingRateIndex(mouse.PollingRate);
                if (idx == -1)
                {
                    return;
                }
                comboBoxPollingRate.SelectedIndex = idx;
            }

            if (mouse.HasAngleSnapping())
            {
                checkBoxAngleSnapping.Checked = mouse.AngleSnapping;
            }

            if (mouse.HasAngleTuning())
            {
                sliderAngleAdjustment.Value = mouse.AngleAdjustmentDegrees;
            }

            if (mouse.HasAutoPowerOff())
            {
                if (mouse.PowerOffSetting == PowerOffSetting.Never)
                {
                    comboBoxAutoPowerOff.SelectedIndex = comboBoxAutoPowerOff.Items.Count - 1;
                }
                else
                {
                    comboBoxAutoPowerOff.SelectedIndex = (int)mouse.PowerOffSetting;
                }
            }

            if (mouse.HasLowBatteryWarning())
            {
                sliderLowBatteryWarning.Value = mouse.LowBatteryWarning;
            }

            if (mouse.HasLiftOffSetting())
            {
                comboBoxLiftOffDistance.SelectedIndex = (int)mouse.LiftOffDistance;
            }

            if (mouse.HasDebounceSetting())
            {
                sliderButtonDebounce.Min = (int)mouse.MinDebounce();
                sliderButtonDebounce.Max = (int)mouse.MaxDebounce();
                sliderButtonDebounce.Value = (int)mouse.Debounce;
            }

            if (mouse.HasAcceleration())
            {
                sliderAcceleration.Value = mouse.Acceleration;
            }

            if (mouse.HasDeceleration())
            {
                sliderDeceleration.Value = mouse.Deceleration;
            }

            if (mouse.HasMotionSync())
            {
                UpdateMotionSyncState();
            }

            if (mouse.HasZoneMode())
            {
                checkBoxZoneMode.Checked = mouse.ZoneMode;
                sliderZoneModeDPI.Value = mouse.ZoneModeDPI;
                numericUpDownZoneModeDPI.Value = mouse.ZoneModeDPI;

                // Set Zone Mode Polling Rate combobox
                PollingRate[] zoneModePollingRates = { PollingRate.PR1000Hz, PollingRate.PR2000Hz, PollingRate.PR4000Hz, PollingRate.PR8000Hz };
                int prIndex = Array.IndexOf(zoneModePollingRates, mouse.ZoneModePollingRate);
                if (prIndex >= 0) comboBoxZoneModePollingRate.SelectedIndex = prIndex;

                UpdateZoneModeUIState();
            }

            if (mouse.HasButtonBindings())
                VisualizeButtonBindings();
        }

        private void UpdateMotionSyncState()
        {
            if (!mouse.HasMotionSync())
            {
                return;
            }

            bool is8000Hz = mouse.PollingRate == PollingRate.PR8000Hz;
            checkBoxMotionSync.Enabled = !is8000Hz;
            checkBoxMotionSync.Checked = is8000Hz ? false : mouse.MotionSync;
        }

        private void UpdateZoneModeUIState()
        {
            if (!mouse.HasZoneMode())
            {
                return;
            }

            bool zoneModeEnabled = mouse.ZoneMode;

            // Zone Mode controls: enabled when Zone Mode is ON
            sliderZoneModeDPI.Enabled = zoneModeEnabled;
            comboBoxZoneModePollingRate.Enabled = zoneModeEnabled;
            numericUpDownZoneModeDPI.Enabled = zoneModeEnabled;

            // Normal controls: disabled when Zone Mode is ON
            panelDPISettings.Enabled = !zoneModeEnabled;
            tableDPI.Enabled = !zoneModeEnabled;
            comboBoxPollingRate.Enabled = !zoneModeEnabled;
        }

        private void VisualizeBatteryState()
        {
            if (!mouse.HasBattery())
            {
                return;
            }

            labelBatteryState.Text = mouse.Battery + "%";
            labelChargingState.Visible = mouse.Charging;

            if (mouse.Charging)
            {
                pictureBoxBatteryState.BackgroundImage = ControlHelper.TintImage(Properties.Resources.icons8_ladende_batterie_48, foreMain);
            }
            else
            {
                pictureBoxBatteryState.BackgroundImage = ControlHelper.TintImage(Properties.Resources.icons8_batterie_voll_geladen_48, foreMain);
            }
        }

        public void VisusalizeLightingZones()
        {
            bool zoned = mouse.IsLightingZoned();

            buttonLightingZoneAll.Activated = visibleZone == LightingZone.All;
            buttonLightingZoneLogo.Activated = visibleZone == LightingZone.Logo;
            buttonLightingZoneScroll.Activated = visibleZone == LightingZone.Scrollwheel;
            buttonLightingZoneUnderglow.Activated = visibleZone == LightingZone.Underglow;
            buttonLightingZoneDock.Activated = visibleZone == LightingZone.Dock;

            buttonLightingZoneAll.Secondary = zoned;
            buttonLightingZoneLogo.Secondary = !zoned;
            buttonLightingZoneScroll.Secondary = !zoned;
            buttonLightingZoneUnderglow.Secondary = !zoned;
            buttonLightingZoneDock.Secondary = !zoned;

            buttonLightingZoneAll.BackColor = buttonLightingZoneAll.Secondary ? RForm.buttonSecond : RForm.buttonMain;
            buttonLightingZoneLogo.BackColor = buttonLightingZoneLogo.Secondary ? RForm.buttonSecond : RForm.buttonMain;
            buttonLightingZoneScroll.BackColor = buttonLightingZoneScroll.Secondary ? RForm.buttonSecond : RForm.buttonMain;
            buttonLightingZoneUnderglow.BackColor = buttonLightingZoneUnderglow.Secondary ? RForm.buttonSecond : RForm.buttonMain;
            buttonLightingZoneDock.BackColor = buttonLightingZoneDock.Secondary ? RForm.buttonSecond : RForm.buttonMain;
        }

        private void VisusalizeLightingSettings()
        {
            if (!mouse.HasRGB())
            {
                return;
            }

            VisusalizeLightingZones();

            LightingSetting? ls = mouse.LightingSettingForZone(visibleZone);

            if (ls is null)
            {
                //Lighting settings not loaded?
                return;
            }

            sliderBrightness.Value = ls.Brightness;

            checkBoxRandomColor.Visible = mouse.SupportsRandomColor(ls.LightingMode);

            buttonLightingColor.Visible = mouse.SupportsColorSetting(ls.LightingMode);

            comboBoxAnimationSpeed.Visible = mouse.SupportsAnimationSpeed(ls.LightingMode);
            labelAnimationSpeed.Visible = mouse.SupportsAnimationSpeed(ls.LightingMode);
            comboBoxAnimationDirection.Visible = mouse.SupportsAnimationDirection(ls.LightingMode);
            labelAnimationDirection.Visible = mouse.SupportsAnimationDirection(ls.LightingMode);

            comboBoxLightingMode.SelectedIndex = supportedLightingModes.IndexOf(ls.LightingMode);

            if (mouse.SupportsRandomColor(ls.LightingMode))
            {
                checkBoxRandomColor.Checked = ls.RandomColor;
                buttonLightingColor.Visible = !ls.RandomColor;
            }

            buttonLightingColor.SwatchColor = ls.RGBColor;

            //0x09 => 0
            //0x07 => 1
            //0x05 => 2
            comboBoxAnimationSpeed.SelectedIndex = 2 - ((((int)ls.AnimationSpeed) - 5) / 2);
            
            int directionIndex = (int)ls.AnimationDirection;
            if (directionIndex >= 0 && directionIndex < comboBoxAnimationDirection.Items.Count)
            {
                comboBoxAnimationDirection.SelectedIndex = directionIndex;
            }
            else
            {
                comboBoxAnimationDirection.SelectedIndex = 0; // Default to first item
            }
        }


        private void VisualizeDPIButtons()
        {
            // Update to use CurrentDPIProfileCount
            for (int i = 0; i < 4; ++i)
            {
                // Slot logic: 0..Count-1 are normal profiles
                // Slot Count is "Add" button (if Count < 4)

                if (i < mouse.CurrentDPIProfileCount)
                {
                    AsusMouseDPI dpi = mouse.DpiSettings[i];
                    if (dpi is null) continue;

                    dpiButtons[i].Visible = true;
                    if (mouse.HasDPIColors())
                    {
                        dpiButtons[i].Image = ControlHelper.ResizeImage(
                        ControlHelper.TintImage(Properties.Resources.lighting_dot_32, dpi.Color),
                        ControlHelper.Scale);
                        dpiButtons[i].BorderColor = dpi.Color;
                    }
                    else
                    {
                        // Fallback icon if no color support? Usually kept simple
                    }

                    dpiButtons[i].Activated = (mouse.DpiProfile - 1) == i;
                    dpiButtons[i].Text = "DPI " + (i + 1) + "\n" + dpi.DPI;

                    // Clear secondary style (used for Add button)
                    dpiButtons[i].Secondary = false;
                }
                else if (mouse.CanChangeDPICount() && i == mouse.CurrentDPIProfileCount)
                {
                    // This is the "Add" slot
                    dpiButtons[i].Visible = true;
                    dpiButtons[i].Image = null;
                    dpiButtons[i].Text = "+";
                    dpiButtons[i].Activated = false;
                    dpiButtons[i].Secondary = true;
                    dpiButtons[i].BorderColor = Color.Transparent;
                }
                else
                {
                    // Hidden slots
                    dpiButtons[i].Visible = false;
                }
            }
        }


        private void VisualizeCurrentDPIProfile()
        {
            if (mouse.DpiProfile > mouse.DpiSettings.Length)
            {
                Logger.WriteLine($"Wrong mouse DPI: {mouse.DpiProfile}");
                return;
            }

            AsusMouseDPI dpi;

            try
            {
                dpi = mouse.DpiSettings[mouse.DpiProfile - 1];
            }
            catch (Exception ex)
            {
                Logger.WriteLine($"Wrong mouse DPI: {mouse.DpiProfile} {mouse.DpiSettings.Length} {ex.Message}");
                return;
            }

            if (dpi is null)
            {
                return;
            }
            sliderDPI.Value = (int)dpi.DPI;
            buttonDPIColor.SwatchColor = dpi.Color;
        }

        private void AsusMouseSettings_Shown(object? sender, EventArgs e)
        {

            if (Height > Program.settingsForm.Height)
            {
                Top = Program.settingsForm.Top + Program.settingsForm.Height - Height;
            }
            else
            {
                Top = Program.settingsForm.Top;
            }

            Left = Program.settingsForm.Left - Width - 5;


            mouse.Disconnect += Mouse_Disconnect;
            mouse.BatteryUpdated += Mouse_BatteryUpdated;
            mouse.MouseReadyChanged += Mouse_MouseReadyChanged;
            mouse.ProfileChanged += Mouse_ProfileChanged;
            mouse.StartEventListener();
        }

        private void ButtonSync_Click(object sender, EventArgs e)
        {
            RefreshMouseData();
        }

        private void buttonImport_Click(object sender, EventArgs e)
        {
            byte[] data = null;

            Thread t = new Thread(() =>
            {
                OpenFileDialog ofd = new OpenFileDialog();
                ofd.Filter = "G-Helper Mouse Profile V1 (*.gmp1)|*.gmp1";

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    data = File.ReadAllBytes(ofd.FileName);
                }
            });

            t.SetApartmentState(ApartmentState.STA);
            t.Start();
            t.Join();

            if (data == null)
            {
                //User aborted loading
                return;
            }

            if (!mouse.Import(data))
            {
                Logger.WriteLine("Failed to import mouse profile");
                MessageBox.Show(Properties.Strings.MouseImportFailed);
            }
            else
            {
                if (!mouse.IsLightingZoned())
                {
                    visibleZone = LightingZone.All;
                }

                RefreshMouseData();
            }
        }

        private void buttonExport_Click(object sender, EventArgs e)
        {
            Thread t = new Thread(() =>
            {
                SaveFileDialog sfd = new SaveFileDialog();
                sfd.Filter = "G-Helper Mouse Profile V1 (*.gmp1)|*.gmp1";

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    File.WriteAllBytes(sfd.FileName, mouse.Export());
                }
            });

            t.SetApartmentState(ApartmentState.STA);
            t.Start();
            t.Join();
        }
    }
}
